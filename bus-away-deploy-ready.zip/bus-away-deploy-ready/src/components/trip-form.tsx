import { CityList, StateSelect } from "@/components/geo-select";
import { Card, Field, btnCls, inputCls } from "@/components/ui";
import type { trips } from "@/db/schema";
import { BUS_TYPES, tripStatus } from "@/lib/format";
import type { Geo } from "@/lib/trips";

export function TripForm({
  trip,
  geo,
  action,
}: {
  trip?: typeof trips.$inferSelect;
  geo: Geo;
  action: (fd: FormData) => Promise<void>;
}) {
  return (
    <form action={action} className="space-y-4">
      {trip && <input type="hidden" name="id" value={trip.id} />}
      <Card className="space-y-3">
        <h3 className="text-sm font-bold">خط السير</h3>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="ولاية الانطلاق *"><StateSelect name="fromState" geo={geo} defaultValue={trip?.fromState} required /></Field>
          <Field label="مدينة / نقطة الانطلاق *"><input name="fromCity" list="cities" required defaultValue={trip?.fromCity} className={inputCls} /></Field>
          <Field label="ولاية الوجهة *"><StateSelect name="toState" geo={geo} defaultValue={trip?.toState} required /></Field>
          <Field label="مدينة الوجهة *"><input name="toCity" list="cities" required defaultValue={trip?.toCity} className={inputCls} /></Field>
          <Field label="مكان التجمع"><input name="meetingPoint" defaultValue={trip?.meetingPoint ?? ""} className={inputCls} /></Field>
          <Field label="رابط الموقع على الخريطة"><input name="mapUrl" dir="ltr" defaultValue={trip?.mapUrl ?? ""} className={inputCls} placeholder="https://maps.google.com/..." /></Field>
        </div>
        <CityList geo={geo} />
      </Card>
      <Card className="space-y-3">
        <h3 className="text-sm font-bold">الموعد والبص</h3>
        <div className="grid gap-3 sm:grid-cols-3">
          <Field label="تاريخ المغادرة *"><input type="date" name="departureDate" required defaultValue={trip?.departureDate} className={inputCls} /></Field>
          <Field label="وقت المغادرة *"><input type="time" name="departureTime" required defaultValue={trip?.departureTime} className={inputCls} /></Field>
          <Field label="وقت الوصول المتوقع"><input type="time" name="arrivalTime" defaultValue={trip?.arrivalTime ?? ""} className={inputCls} /></Field>
          <Field label="نوع البص">
            <select name="busType" defaultValue={trip?.busType ?? "عادي"} className={inputCls}>
              {BUS_TYPES.map((b) => <option key={b}>{b}</option>)}
            </select>
          </Field>
          <Field label="عدد المقاعد *"><input type="number" name="totalSeats" min={1} max={100} required defaultValue={trip?.totalSeats ?? 40} className={inputCls} /></Field>
          <Field label="سعر التذكرة *"><input type="number" name="price" min={0} required defaultValue={trip?.price} className={inputCls} /></Field>
          <Field label="حالة الرحلة">
            <select name="status" defaultValue={trip?.status === "full" ? "open" : (trip?.status ?? "open")} className={inputCls}>
              {Object.entries(tripStatus).filter(([k]) => k !== "full").map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
            </select>
          </Field>
        </div>
        {trip && <p className="text-xs text-slate-500">المقاعد المتاحة حالياً: {trip.availableSeats} (تُحسب تلقائياً من الحجوزات)</p>}
        <Field label="ملاحظات الرحلة">
          <textarea name="notes" rows={3} defaultValue={trip?.notes ?? ""} className={inputCls} />
        </Field>
      </Card>
      <button className={btnCls()}>{trip ? "حفظ التعديلات" : "إضافة الرحلة"}</button>
    </form>
  );
}
