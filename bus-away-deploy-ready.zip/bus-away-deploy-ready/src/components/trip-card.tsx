import Link from "next/link";
import type { companies, trips } from "@/db/schema";
import { Logo, StatusBadge } from "@/components/ui";
import { fmtDate, fmtTime, money, tripStatus } from "@/lib/format";

export function TripCard({
  trip,
  company,
  currency,
  href,
}: {
  trip: typeof trips.$inferSelect;
  company: typeof companies.$inferSelect;
  currency: string;
  href: string;
}) {
  return (
    <Link href={href} className="block rounded-2xl bg-white p-4 shadow-sm ring-1 ring-slate-200 transition hover:ring-primary/50">
      <div className="mb-3 flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <Logo src={company.logo} name={company.name} size={32} />
          <span className="text-sm font-semibold text-slate-700">{company.name}</span>
        </div>
        <StatusBadge map={tripStatus} value={trip.status} />
      </div>
      <div className="flex items-center gap-2 text-base font-bold text-slate-900">
        <span>{trip.fromCity}</span>
        <span className="text-primary">←</span>
        <span>{trip.toCity}</span>
      </div>
      <div className="mt-2 grid grid-cols-2 gap-x-3 gap-y-1 text-xs text-slate-500">
        <span>📅 {fmtDate(trip.departureDate)}</span>
        <span>🕗 {fmtTime(trip.departureTime)}</span>
        <span>🚌 {trip.busType}</span>
        <span>💺 متاح {trip.availableSeats} مقعداً</span>
      </div>
      <div className="mt-3 flex items-center justify-between border-t border-slate-100 pt-3">
        <span className="text-lg font-bold text-primary">{money(trip.price, currency)}</span>
        <span className="text-xs font-semibold text-primary">التفاصيل ←</span>
      </div>
    </Link>
  );
}
