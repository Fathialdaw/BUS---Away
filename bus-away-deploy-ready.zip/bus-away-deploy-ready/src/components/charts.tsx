import { Card } from "@/components/ui";
import type { Report, Point } from "@/lib/reports";
import { money } from "@/lib/format";

function Bars({ data, suffix = "", color = "bg-primary" }: { data: Point[]; suffix?: string; color?: string }) {
  const max = Math.max(1, ...data.map((d) => d.value));
  if (!data.length) return <p className="py-6 text-center text-sm text-slate-400">لا توجد بيانات</p>;
  return (
    <div className="space-y-2.5">
      {data.map((d) => (
        <div key={d.label}>
          <div className="mb-1 flex justify-between text-xs text-slate-600">
            <span className="truncate">{d.label}</span>
            <span className="font-semibold">
              {d.value.toLocaleString("en-US")}
              {suffix}
            </span>
          </div>
          <div className="h-2.5 overflow-hidden rounded-full bg-slate-100">
            <div className={`h-full rounded-full ${color}`} style={{ width: `${(d.value / max) * 100}%` }} />
          </div>
        </div>
      ))}
    </div>
  );
}

function Columns({ data, color = "bg-primary", data2, color2 = "bg-rose-400" }: { data: Point[]; color?: string; data2?: Point[]; color2?: string }) {
  const max = Math.max(1, ...data.map((d) => d.value), ...(data2 ?? []).map((d) => d.value));
  return (
    <div className="flex h-44 items-end gap-1.5" dir="ltr">
      {data.map((d, i) => (
        <div key={d.label} className="flex h-full flex-1 flex-col items-center justify-end gap-1">
          <div className="flex h-full w-full items-end justify-center gap-0.5">
            <div className={`w-full max-w-5 rounded-t ${color}`} style={{ height: `${Math.max(2, (d.value / max) * 85)}%` }} title={String(d.value)} />
            {data2 && (
              <div className={`w-full max-w-5 rounded-t ${color2}`} style={{ height: `${Math.max(2, ((data2[i]?.value ?? 0) / max) * 85)}%` }} title={String(data2[i]?.value ?? 0)} />
            )}
          </div>
          <span className="text-[9px] text-slate-500">{d.label}</span>
        </div>
      ))}
    </div>
  );
}

function Box({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <Card>
      <h3 className="mb-3 text-sm font-bold text-slate-800">{title}</h3>
      {children}
    </Card>
  );
}

export function ReportView({ r, currency, showCompanies }: { r: Report; currency: string; showCompanies?: boolean }) {
  const totalSeats = r.seats.sold + r.seats.available;
  const pct = totalSeats ? Math.round((r.seats.sold / totalSeats) * 100) : 0;
  const rev = r.revenue.reduce((a, b) => a + b.value, 0);
  const exp = r.expenses.reduce((a, b) => a + b.value, 0);
  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <Box title="المقاعد المتاحة والمباعة (الرحلات النشطة)">
        <div className="mb-3 h-5 overflow-hidden rounded-full bg-emerald-100">
          <div className="h-full bg-primary" style={{ width: `${pct}%` }} />
        </div>
        <div className="flex justify-between text-sm">
          <span className="text-primary">مباعة: {r.seats.sold}</span>
          <span className="font-semibold">{pct}%</span>
          <span className="text-emerald-600">متاحة: {r.seats.available}</span>
        </div>
      </Box>
      <Box title="الرحلات المنفذة والملغاة">
        <Bars
          data={[
            { label: "منفذة", value: r.tripsDone.done },
            { label: "قادمة", value: r.tripsDone.upcoming },
            { label: "ملغاة", value: r.tripsDone.cancelled },
          ]}
          color="bg-teal-500"
        />
      </Box>
      <Box title="الحجوزات اليومية (آخر 14 يوماً)">
        <Columns data={r.daily} />
      </Box>
      <Box title="الحجوزات الشهرية">
        <Columns data={r.monthly} color="bg-indigo-500" />
      </Box>
      <Box title={`الإيرادات والمصروفات (آخر 6 أشهر) - الإيراد ${money(rev, currency)} / المصروف ${money(exp, currency)}`}>
        <Columns data={r.revenue} data2={r.expenses} color="bg-emerald-500" />
        <div className="mt-2 flex gap-4 text-xs text-slate-500">
          <span>🟩 الإيرادات</span>
          <span>🟥 المصروفات</span>
          <span className="mr-auto font-semibold text-slate-700">الصافي: {money(rev - exp, currency)}</span>
        </div>
      </Box>
      <Box title="نسبة إشغال كل رحلة (%)">
        <Bars data={r.occupancy} suffix="%" color="bg-orange-500" />
      </Box>
      <Box title="أكثر الرحلات طلباً">
        <Bars data={r.topTrips} color="bg-purple-500" />
      </Box>
      <Box title="عدد الركاب حسب الولاية">
        <Bars data={r.byState} color="bg-sky-500" />
      </Box>
      <Box title="طرق الدفع الأكثر استخداماً">
        <Bars data={r.methods} color="bg-pink-500" />
      </Box>
      {showCompanies && (
        <Box title="أداء كل شركة">
          <div className="space-y-3">
            {r.companies.map((c) => (
              <div key={c.name} className="rounded-xl bg-slate-50 p-3 text-sm">
                <div className="font-semibold">{c.name}</div>
                <div className="mt-1 flex flex-wrap gap-x-4 text-xs text-slate-600">
                  <span>رحلات: {c.trips}</span>
                  <span>حجوزات: {c.bookings}</span>
                  <span>إيراد: {money(c.revenue, currency)}</span>
                </div>
              </div>
            ))}
          </div>
        </Box>
      )}
    </div>
  );
}
