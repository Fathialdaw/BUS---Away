import { inputCls } from "@/components/ui";
import type { Geo } from "@/lib/trips";

/** قائمة اختيار تجمع الولايات والمدن */
export function GeoSelect({
  name,
  geo,
  defaultValue,
  placeholder = "الكل",
  required,
}: {
  name: string;
  geo: Geo;
  defaultValue?: string;
  placeholder?: string;
  required?: boolean;
}) {
  return (
    <select name={name} defaultValue={defaultValue ?? ""} required={required} className={inputCls}>
      <option value="">{placeholder}</option>
      <optgroup label="الولايات">
        {geo.map((g) => (
          <option key={`s-${g.state}`} value={g.state}>
            {g.state} (كل الولاية)
          </option>
        ))}
      </optgroup>
      {geo.map((g) => (
        <optgroup key={g.state} label={`مدن ${g.state}`}>
          {g.cities.map((c) => (
            <option key={`${g.state}-${c}`} value={c}>
              {c}
            </option>
          ))}
        </optgroup>
      ))}
    </select>
  );
}

export function StateSelect({ name, geo, defaultValue, required }: { name: string; geo: Geo; defaultValue?: string | null; required?: boolean }) {
  return (
    <select name={name} defaultValue={defaultValue ?? ""} required={required} className={inputCls}>
      <option value="">اختر الولاية</option>
      {geo.map((g) => (
        <option key={g.state} value={g.state}>
          {g.state}
        </option>
      ))}
    </select>
  );
}

export function CityList({ geo, id = "cities" }: { geo: Geo; id?: string }) {
  return (
    <datalist id={id}>
      {geo.flatMap((g) => g.cities).map((c, i) => (
        <option key={`${c}-${i}`} value={c} />
      ))}
    </datalist>
  );
}
