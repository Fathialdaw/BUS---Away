import Link from "next/link";
import { Empty, StatusBadge, td, th } from "@/components/ui";
import { bookingStatus, fmtDate, fmtDateTime, fmtTime, money, paymentStatus } from "@/lib/format";
import type { BookingRow } from "@/lib/bookings-list";

export function BookingsTable({
  rows,
  currency,
  base,
  showCompany,
}: {
  rows: BookingRow[];
  currency: string;
  base?: string;
  showCompany?: boolean;
}) {
  if (!rows.length) return <Empty text="لا توجد حجوزات مطابقة" icon="🎫" />;
  return (
    <div className="overflow-x-auto rounded-2xl bg-white shadow-sm ring-1 ring-slate-200">
      <table className="w-full min-w-[1100px] border-collapse">
        <thead>
          <tr>
            {["رقم الحجز", "الراكب", "رقم الراكب", "الهاتف", ...(showCompany ? ["الشركة"] : []), "الرحلة", "المقعد", "السعر", "طريقة الدفع", "رقم العملية", "الإشعار", "حالة الدفع", "حالة الحجز", "تاريخ الحجز", ""].map((h) => (
              <th key={h} className={th}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100">
          {rows.map(({ b, pax, t, c, pay }) => (
            <tr key={b.id} className="hover:bg-slate-50">
              <td className={`${td} font-mono text-xs`}>{b.bookingNumber}</td>
              <td className={`${td} font-semibold`}>{pax.name}</td>
              <td className={td}>{pax.passengerNumber}</td>
              <td className={td} dir="ltr">{pax.phone}</td>
              {showCompany && <td className={td}>{c.name}</td>}
              <td className={td}>
                {t.fromCity} ← {t.toCity}
                <div className="text-[11px] text-slate-400">{fmtDate(t.departureDate)} {fmtTime(t.departureTime)}</div>
              </td>
              <td className={`${td} font-bold`}>{b.seatNumber}</td>
              <td className={td}>{money(b.price, currency)}</td>
              <td className={td}>{pay?.paymentMethod ?? "-"}</td>
              <td className={td}>{pay?.transactionNumber ?? "-"}</td>
              <td className={td}>
                {pay?.receiptImage ? (
                  <a href={pay.receiptImage} target="_blank" rel="noreferrer" className="text-primary">🧾 عرض</a>
                ) : (
                  "-"
                )}
              </td>
              <td className={td}>{pay ? <StatusBadge map={paymentStatus} value={pay.status} /> : "-"}</td>
              <td className={td}><StatusBadge map={bookingStatus} value={b.status} /></td>
              <td className={td}>{fmtDateTime(b.createdAt)}</td>
              <td className={td}>
                {base && <Link href={`${base}/${b.id}`} className="font-semibold text-primary">فتح</Link>}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
