import type { ReactNode } from "react";
import { ThemeToggle } from "@/components/theme-toggle";
import { Logo } from "@/components/ui";
import { getSettings } from "@/lib/settings";

export async function AuthShell({
  title,
  subtitle,
  children,
  badge,
  returnTo,
}: {
  title: string;
  subtitle?: string;
  children: ReactNode;
  badge?: string;
  returnTo?: string;
}) {
  const s = await getSettings();
  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-b from-primary/15 to-slate-100 p-4">
      {returnTo && (
        <div className="fixed right-3 top-3 z-20">
          <ThemeToggle returnTo={returnTo} />
        </div>
      )}
      <div className="w-full max-w-md">
        <div className="mb-5 flex flex-col items-center gap-2 text-center">
          <Logo src={s.app_logo} name={s.app_name} size={64} />
          <div className="text-lg font-extrabold text-slate-900">{s.app_name}</div>
          {badge && <span className="rounded-full bg-primary px-3 py-0.5 text-xs font-semibold text-white">{badge}</span>}
        </div>
        <div className="rounded-3xl bg-white p-6 shadow-xl ring-1 ring-slate-200">
          <h1 className="text-xl font-bold text-slate-900">{title}</h1>
          {subtitle && <p className="mt-1 text-sm text-slate-500">{subtitle}</p>}
          <div className="mt-5">{children}</div>
        </div>
      </div>
    </div>
  );
}
