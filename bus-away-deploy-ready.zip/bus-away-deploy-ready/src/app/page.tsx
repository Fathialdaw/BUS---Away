import Link from "next/link";
import { headers } from "next/headers";
import { ThemeToggle } from "@/components/theme-toggle";
import { Logo } from "@/components/ui";
import { getSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";

const APPS = [
  {
    href: "/passenger",
    icon: "🧳",
    title: "تطبيق المسافر",
    desc: "ابحث عن رحلتك، اختر مقعدك، حوّل المبلغ، واحصل على تذكرتك الإلكترونية مع رمز QR وتنبيهات المواعيد.",
    color: "from-blue-600 to-blue-800",
    demo: "الراكب: 0912345678 / pass123",
  },
  {
    href: "/company",
    icon: "🏢",
    title: "تطبيق إدارة الشركات",
    desc: "للمديرين والموظفين: إدارة الرحلات والحجوزات، مراجعة التحويلات، فحص التذاكر، التقارير والدردشة بين المديرين.",
    color: "from-teal-600 to-teal-800",
    demo: "المدير: nile.manager@bus.sd / manager123",
  },
  {
    href: "/admin",
    icon: "🛡️",
    title: "تطبيق مدير النظام",
    desc: "إدارة الشركات والمستخدمين والإعدادات العامة والولايات وطرق الدفع، مع التقارير العامة وسجل العمليات.",
    color: "from-violet-600 to-violet-800",
    demo: "المدير: admin@bus.sd / admin123",
  },
];

export default async function Home() {
  const s = await getSettings();
  const h = await headers();
  const host = h.get("host") ?? "";
  return (
    <main className="min-h-screen bg-gradient-to-b from-slate-100 to-slate-300 px-4 py-10 text-slate-900 dark:from-slate-950 dark:to-slate-800 dark:text-white">
      <div className="fixed right-4 top-4 z-20">
        <ThemeToggle returnTo="/" />
      </div>
      <div className="mx-auto max-w-5xl">
        <div className="mb-10 flex flex-col items-center gap-3 text-center">
          <Logo src={s.app_logo} name={s.app_name} size={72} />
          <h1 className="text-3xl font-extrabold">{s.app_name}</h1>
          <p className="max-w-xl text-slate-600 dark:text-slate-300">نظام متكامل لحجز السفر بالبصات، مقسّم إلى ثلاثة تطبيقات مستقلة قابلة للتثبيت على الهاتف كتطبيقات.</p>
        </div>
        <div className="grid gap-5 md:grid-cols-3">
          {APPS.map((a) => (
            <Link key={a.href} href={a.href} className={`group flex flex-col rounded-3xl bg-gradient-to-br ${a.color} p-6 shadow-xl ring-1 ring-white/10 transition hover:-translate-y-1`}>
              <div className="text-4xl">{a.icon}</div>
              <h2 className="mt-3 text-xl font-bold">{a.title}</h2>
              <p className="mt-2 flex-1 text-sm leading-7 text-white/80">{a.desc}</p>
              <div className="mt-4 rounded-xl bg-black/20 px-3 py-2 text-[11px] text-white/80" dir="ltr">{a.demo}</div>
              <div className="mt-4 rounded-xl bg-white px-4 py-2.5 text-center text-sm font-bold text-slate-900">فتح التطبيق ←</div>
            </Link>
          ))}
        </div>
        <div className="mt-10 rounded-2xl bg-slate-900/5 p-5 text-sm leading-7 text-slate-600 ring-1 ring-slate-300/70 dark:bg-white/5 dark:text-slate-300 dark:ring-white/10">
          <b className="text-slate-900 dark:text-white">🔗 رابط مستقل لكل تطبيق:</b>
          <div className="mt-2 grid gap-2 sm:grid-cols-3" dir="ltr">
            {APPS.map((a) => (
              <Link key={a.href} href={a.href} className="break-all rounded-xl bg-slate-900/10 px-3 py-2 font-mono text-xs text-slate-900 hover:bg-slate-900/20 dark:bg-white/10 dark:text-white dark:hover:bg-white/20">
                https://{host}{a.href}
              </Link>
            ))}
          </div>
          <p className="mt-3">
            كل تطبيق يعمل بجلسة وبيانات ونطاق تثبيت مستقل عن الأخرين. وعند ربط دومين خاص للنشر تُفعَّل تلقائياً روابط النطاقات الفرعية:
            <span className="mx-1 font-mono text-xs" dir="ltr">passenger.yourdomain.com</span> •
            <span className="mx-1 font-mono text-xs" dir="ltr">company.yourdomain.com</span> •
            <span className="mx-1 font-mono text-xs" dir="ltr">admin.yourdomain.com</span>
          </p>
        </div>
        <div className="mt-4 rounded-2xl bg-slate-900/5 p-5 text-sm leading-7 text-slate-600 ring-1 ring-slate-300/70 dark:bg-white/5 dark:text-slate-300 dark:ring-white/10">
          <b className="text-slate-900 dark:text-white">📲 تحميل التطبيقات:</b> افتح أي تطبيق من الأعلى في متصفح هاتفك ثم اضغط زر «تثبيت» في الشريط العلوي (أو من قائمة المتصفح: «إضافة إلى الشاشة الرئيسية»). كل تطبيق يُثبَّت بشكل منفصل بأيقونة واسم خاصين به.
        </div>
        <p className="mt-6 text-center text-xs text-slate-500 dark:text-slate-400">{s.contact_phone} • {s.contact_email}</p>
      </div>
    </main>
  );
}
