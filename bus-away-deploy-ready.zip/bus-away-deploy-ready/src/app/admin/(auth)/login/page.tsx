import { AuthShell } from "@/components/auth-shell";
import { Field, Flash, btnCls, inputCls } from "@/components/ui";
import { adminLoginAction } from "../../actions";

export const metadata = { title: "تسجيل الدخول" };

export default async function AdminLogin({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  return (
    <AuthShell title="دخول مدير النظام" subtitle="لوحة التحكم العامة بالنظام" badge="تطبيق مدير النظام" returnTo="/admin/login">
      <Flash sp={sp} />
      <form action={adminLoginAction} className="space-y-4">
        <Field label="البريد الإلكتروني أو رقم الهاتف">
          <input name="identifier" required className={inputCls} />
        </Field>
        <Field label="كلمة المرور">
          <input name="password" type="password" required className={inputCls} />
        </Field>
        <button className={`${btnCls()} w-full`}>تسجيل الدخول</button>
      </form>
      <div className="mt-5 rounded-xl bg-slate-50 p-3 text-xs text-slate-500">
        حساب تجريبي: <b dir="ltr">admin@bus.sd</b> / <b dir="ltr">admin123</b>
      </div>
    </AuthShell>
  );
}
