import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { chatRooms, companies, messages, users } from "@/db/schema";
import { Card, Empty, Flash, PageTitle } from "@/components/ui";
import { fmtDateTime } from "@/lib/format";
import { clearReportAction } from "@/app/admin/actions";

export const metadata = { title: "مراقبة الدردشة" };

export default async function AdminChat({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  const rows = await db
    .select({ m: messages, u: users, c: companies, r: chatRooms })
    .from(messages)
    .innerJoin(users, eq(users.id, messages.senderId))
    .innerJoin(chatRooms, eq(chatRooms.id, messages.roomId))
    .leftJoin(companies, eq(companies.id, users.companyId))
    .orderBy(desc(messages.id))
    .limit(120);
  const reported = rows.filter((r) => r.m.reported);
  const bubble = ({ m, u, c, r }: (typeof rows)[number], withAction: boolean) => (
    <Card key={m.id}>
      <div className="flex items-start justify-between gap-2 text-xs text-slate-500">
        <span><b className="text-slate-800">{u.name}</b> ({c?.name ?? "إدارة"}) • {r.isGroup ? `مجموعة: ${r.name}` : "فردية"}</span>
        <span>{fmtDateTime(m.createdAt)}</span>
      </div>
      <p className="mt-2 whitespace-pre-wrap text-sm">{m.message || "📎 مرفق"}</p>
      {m.attachment && <a href={m.attachment} target="_blank" rel="noreferrer" className="text-xs text-primary underline">عرض المرفق</a>}
      {m.reported && <p className="mt-2 text-xs text-red-600">🚩 بلاغ: {m.reportReason}</p>}
      {withAction && (
        <form action={clearReportAction} className="mt-2">
          <input type="hidden" name="id" value={m.id} />
          <button className="cursor-pointer text-xs font-semibold text-primary">إغلاق البلاغ</button>
        </form>
      )}
    </Card>
  );
  return (
    <div className="space-y-4">
      <PageTitle title="مراقبة الدردشة" subtitle="عرض للقراءة فقط لمحادثات مديري المكاتب والرسائل المبلّغ عنها" />
      <Flash sp={sp} />
      <h2 className="text-sm font-bold text-red-600">رسائل مبلّغ عنها ({reported.length})</h2>
      {reported.length === 0 ? <Empty text="لا توجد بلاغات" icon="✅" /> : <div className="grid gap-3 md:grid-cols-2">{reported.map((r) => bubble(r, true))}</div>}
      <h2 className="text-sm font-bold">آخر الرسائل</h2>
      {rows.length === 0 ? <Empty text="لا توجد رسائل" icon="💬" /> : <div className="grid gap-3 md:grid-cols-2">{rows.map((r) => bubble(r, false))}</div>}
    </div>
  );
}
