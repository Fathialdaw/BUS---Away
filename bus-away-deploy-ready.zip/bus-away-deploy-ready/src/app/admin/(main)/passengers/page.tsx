import { desc } from "drizzle-orm";
import { db } from "@/db";
import { passengers } from "@/db/schema";
import { Flash, PageTitle, StatusBadge, td, th } from "@/components/ui";
import { fmtDate, passengerStatus } from "@/lib/format";
import { setPassengerStatusAction } from "@/app/admin/actions";

export const metadata = { title: "الركاب" };

export default async function AdminPassengers({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  const rows = await db.select().from(passengers).orderBy(desc(passengers.id)).limit(300);
  return (
    <div className="space-y-4">
      <PageTitle title="الركاب" subtitle={`${rows.length} راكب`} />
      <Flash sp={sp} />
      <div className="overflow-x-auto rounded-2xl bg-white ring-1 ring-slate-200">
        <table className="w-full min-w-[800px]">
          <thead><tr>{["رقم الراكب", "الاسم", "الهاتف", "الرقم الوطني", "الولاية / المدينة", "التسجيل", "الحالة", ""].map((h) => <th key={h} className={th}>{h}</th>)}</tr></thead>
          <tbody className="divide-y divide-slate-100">
            {rows.map((p) => (
              <tr key={p.id}>
                <td className={td}>{p.passengerNumber}</td>
                <td className={`${td} font-semibold`}>{p.name}</td>
                <td className={td} dir="ltr">{p.phone}</td>
                <td className={td}>{p.nationalId ?? "-"}</td>
                <td className={td}>{p.state ?? "-"} / {p.city ?? "-"}</td>
                <td className={td}>{fmtDate(p.createdAt)}</td>
                <td className={td}><StatusBadge map={passengerStatus} value={p.status} /></td>
                <td className={td}>
                  <form action={setPassengerStatusAction} className="flex gap-2">
                    <input type="hidden" name="id" value={p.id} />
                    {p.status !== "active" && <button name="status" value="active" className="cursor-pointer text-xs font-semibold text-emerald-600">تفعيل</button>}
                    {p.status !== "suspended" && <button name="status" value="suspended" className="cursor-pointer text-xs font-semibold text-red-600">إيقاف</button>}
                  </form>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
