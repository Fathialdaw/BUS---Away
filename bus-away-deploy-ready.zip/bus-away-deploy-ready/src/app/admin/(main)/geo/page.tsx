import { asc } from "drizzle-orm";
import { db } from "@/db";
import { cities, states } from "@/db/schema";
import { ConfirmButton } from "@/components/client";
import { Card, Field, Flash, PageTitle, btnCls, inputCls } from "@/components/ui";
import { addCityAction, addStateAction, deleteCityAction, deleteStateAction } from "@/app/admin/actions";

export const metadata = { title: "الولايات والمدن" };

export default async function AdminGeo({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  const ss = await db.select().from(states).orderBy(asc(states.name));
  const cs = await db.select().from(cities).orderBy(asc(cities.name));
  return (
    <div className="space-y-4">
      <PageTitle title="إدارة الولايات والمدن" subtitle={`${ss.length} ولاية • ${cs.length} مدينة`} />
      <Flash sp={sp} />
      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <form action={addStateAction} className="flex items-end gap-2">
            <Field label="ولاية جديدة"><input name="name" required className={inputCls} /></Field>
            <button className={btnCls()}>إضافة</button>
          </form>
        </Card>
        <Card>
          <form action={addCityAction} className="flex items-end gap-2">
            <Field label="الولاية">
              <select name="stateId" required className={inputCls}>{ss.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}</select>
            </Field>
            <Field label="مدينة جديدة"><input name="name" required className={inputCls} /></Field>
            <button className={btnCls()}>إضافة</button>
          </form>
        </Card>
      </div>
      <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
        {ss.map((s) => (
          <Card key={s.id}>
            <div className="mb-2 flex items-center justify-between">
              <h3 className="font-bold">{s.name}</h3>
              <form action={deleteStateAction}>
                <input type="hidden" name="id" value={s.id} />
                <ConfirmButton message="حذف الولاية وجميع مدنها؟" className="cursor-pointer text-xs font-semibold text-red-600">حذف</ConfirmButton>
              </form>
            </div>
            <div className="flex flex-wrap gap-2">
              {cs.filter((c) => c.stateId === s.id).map((c) => (
                <form key={c.id} action={deleteCityAction} className="flex items-center gap-1 rounded-full bg-slate-100 px-3 py-1 text-xs">
                  <input type="hidden" name="id" value={c.id} />
                  {c.name}
                  <ConfirmButton message={`حذف مدينة ${c.name}؟`} className="cursor-pointer text-red-500">✕</ConfirmButton>
                </form>
              ))}
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
