import { asc } from "drizzle-orm";
import { db } from "@/db";
import { paymentTypes } from "@/db/schema";
import { ConfirmButton } from "@/components/client";
import { Badge, Card, Field, Flash, PageTitle, btnCls, inputCls } from "@/components/ui";
import { addPaymentTypeAction, deletePaymentTypeAction, togglePaymentTypeAction } from "@/app/admin/actions";

export const metadata = { title: "طرق الدفع" };

export default async function PaymentTypesPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  const rows = await db.select().from(paymentTypes).orderBy(asc(paymentTypes.id));
  return (
    <div className="max-w-2xl space-y-4">
      <PageTitle title="أنواع الدفع" subtitle="الطرق التي يمكن للشركات إنشاء حسابات بها" />
      <Flash sp={sp} />
      <Card>
        <form action={addPaymentTypeAction} className="flex items-end gap-2">
          <Field label="طريقة دفع جديدة"><input name="name" required className={inputCls} /></Field>
          <button className={btnCls()}>إضافة</button>
        </form>
      </Card>
      <div className="space-y-2">
        {rows.map((t) => (
          <Card key={t.id} className="flex items-center justify-between">
            <div className="flex items-center gap-3"><b>{t.name}</b><Badge tone={t.active ? "green" : "gray"}>{t.active ? "مفعلة" : "معطلة"}</Badge></div>
            <div className="flex gap-3">
              <form action={togglePaymentTypeAction}>
                <input type="hidden" name="id" value={t.id} />
                <button className="cursor-pointer text-xs font-semibold text-primary">{t.active ? "تعطيل" : "تفعيل"}</button>
              </form>
              <form action={deletePaymentTypeAction}>
                <input type="hidden" name="id" value={t.id} />
                <ConfirmButton message="حذف طريقة الدفع؟" className="cursor-pointer text-xs font-semibold text-red-600">حذف</ConfirmButton>
              </form>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
