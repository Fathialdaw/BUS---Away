import { and, asc, desc, eq, gte, inArray } from "drizzle-orm";
import { db } from "@/db";
import { adminBookingRequests, companies, passengers, trips } from "@/db/schema";
import { Card, Empty, Field, Flash, PageTitle, StatusBadge, btnCls, inputCls } from "@/components/ui";
import { fmtDate, fmtDateTime, fmtTime, requestStatus, todayStr } from "@/lib/format";
import { createBookingRequestAction } from "@/app/admin/actions";

export const metadata = { title: "حجز باسم شركة" };

export default async function AdminRequests({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  const openTrips = await db
    .select({ t: trips, c: companies })
    .from(trips)
    .innerJoin(companies, eq(companies.id, trips.companyId))
    .where(and(inArray(trips.status, ["open"]), gte(trips.departureDate, todayStr()), eq(companies.status, "active")))
    .orderBy(asc(companies.name), asc(trips.departureDate))
    .limit(100);
  const pax = await db.select().from(passengers).where(eq(passengers.status, "active")).orderBy(asc(passengers.name)).limit(300);
  const reqs = await db
    .select({ r: adminBookingRequests, t: trips, c: companies, p: passengers })
    .from(adminBookingRequests)
    .innerJoin(trips, eq(trips.id, adminBookingRequests.tripId))
    .innerJoin(companies, eq(companies.id, adminBookingRequests.companyId))
    .innerJoin(passengers, eq(passengers.id, adminBookingRequests.passengerId))
    .orderBy(desc(adminBookingRequests.id))
    .limit(100);
  return (
    <div className="space-y-4">
      <PageTitle title="طلب حجز باسم شركة" subtitle="لا يُنفذ الحجز إلا بعد موافقة مدير مكتب الشركة، وتوثق العملية في سجل النظام" />
      <Flash sp={sp} />
      <Card>
        <form action={createBookingRequestAction} className="grid gap-3 md:grid-cols-2">
          <Field label="الرحلة (الشركة)">
            <select name="tripId" required className={inputCls}>
              <option value="">اختر الرحلة</option>
              {openTrips.map(({ t, c }) => (
                <option key={t.id} value={t.id}>{c.name} — {t.fromCity} ← {t.toCity} ({t.departureDate} {t.departureTime})</option>
              ))}
            </select>
          </Field>
          <Field label="الراكب">
            <select name="passengerId" required className={inputCls}>
              <option value="">اختر الراكب</option>
              {pax.map((p) => <option key={p.id} value={p.id}>{p.name} ({p.passengerNumber})</option>)}
            </select>
          </Field>
          <Field label="رقم المقعد"><input name="seat" type="number" min={1} required className={inputCls} /></Field>
          <Field label="ملاحظة لمدير المكتب"><input name="note" className={inputCls} /></Field>
          <div className="md:col-span-2"><button className={btnCls()}>إرسال الطلب لمدير المكتب</button></div>
        </form>
      </Card>
      {reqs.length === 0 ? (
        <Empty text="لا توجد طلبات" icon="📨" />
      ) : (
        <div className="grid gap-3 md:grid-cols-2">
          {reqs.map(({ r, t, c, p }) => (
            <Card key={r.id}>
              <div className="flex items-start justify-between">
                <div className="font-bold">{c.name}</div>
                <StatusBadge map={requestStatus} value={r.status} />
              </div>
              <div className="mt-2 space-y-1 text-sm text-slate-600">
                <div>{t.fromCity} ← {t.toCity} • {fmtDate(t.departureDate)} {fmtTime(t.departureTime)}</div>
                <div>الراكب: {p.name} • المقعد {r.seatNumber}</div>
                <div className="text-xs text-slate-400">{fmtDateTime(r.createdAt)}{r.decidedAt ? ` • القرار: ${fmtDateTime(r.decidedAt)}` : ""}</div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
