import { BookingsTable } from "@/components/bookings-table";
import { PageTitle, btnCls, inputCls } from "@/components/ui";
import { releaseExpired } from "@/lib/booking";
import { listBookings } from "@/lib/bookings-list";
import { bookingStatus, one } from "@/lib/format";
import { getSettings } from "@/lib/settings";

export const metadata = { title: "الحجوزات" };

export default async function AdminBookings({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  await releaseExpired();
  const s = await getSettings();
  const status = one(sp.status);
  const q = one(sp.q);
  const rows = await listBookings({ status, q, limit: 200 });
  return (
    <div className="space-y-4">
      <PageTitle title="جميع الحجوزات" subtitle="عرض فقط — تُراجع المدفوعات من قبل الشركات" />
      <form className="flex flex-wrap gap-2">
        <select name="status" defaultValue={status} className={`${inputCls} max-w-48`}>
          <option value="">كل الحالات</option>
          {Object.entries(bookingStatus).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
        </select>
        <input name="q" defaultValue={q} placeholder="بحث..." className={`${inputCls} max-w-xs`} />
        <button className={btnCls()}>بحث</button>
      </form>
      <BookingsTable rows={rows} currency={s.currency} showCompany />
    </div>
  );
}
