import Link from "next/link";
import { asc, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { companies, trips } from "@/db/schema";
import { Empty, PageTitle, StatusBadge, cx, td, th } from "@/components/ui";
import { fmtDate, fmtTime, money, one, tripStatus } from "@/lib/format";
import { getSettings } from "@/lib/settings";

export const metadata = { title: "الرحلات" };

export default async function AdminTrips({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  const s = await getSettings();
  const cid = Number(one(sp.company)) || 0;
  const cos = await db.select().from(companies).orderBy(asc(companies.id));
  const q = db.select({ t: trips, c: companies }).from(trips).innerJoin(companies, eq(companies.id, trips.companyId));
  const rows = await (cid ? q.where(eq(trips.companyId, cid)) : q).orderBy(desc(trips.departureDate), desc(trips.id)).limit(200);
  return (
    <div className="space-y-4">
      <PageTitle title="الرحلات" subtitle="عرض لجميع رحلات الشركات (تُدار من قبل مديري المكاتب)" />
      <div className="flex flex-wrap gap-2">
        <Link href="/admin/trips" className={cx("rounded-full px-3 py-1.5 text-xs font-semibold", !cid ? "bg-primary text-white" : "bg-white ring-1 ring-slate-200")}>الكل</Link>
        {cos.map((c) => (
          <Link key={c.id} href={`/admin/trips?company=${c.id}`} className={cx("rounded-full px-3 py-1.5 text-xs font-semibold", cid === c.id ? "bg-primary text-white" : "bg-white ring-1 ring-slate-200")}>{c.name}</Link>
        ))}
      </div>
      {rows.length === 0 ? (
        <Empty text="لا توجد رحلات" icon="🚌" />
      ) : (
        <div className="overflow-x-auto rounded-2xl bg-white ring-1 ring-slate-200">
          <table className="w-full min-w-[800px]">
            <thead><tr>{["الشركة", "الخط", "التاريخ", "المغادرة", "البص", "المقاعد", "السعر", "الحالة"].map((h) => <th key={h} className={th}>{h}</th>)}</tr></thead>
            <tbody className="divide-y divide-slate-100">
              {rows.map(({ t, c }) => (
                <tr key={t.id}>
                  <td className={td}>{c.name}</td>
                  <td className={`${td} font-semibold`}>{t.fromCity} ← {t.toCity}</td>
                  <td className={td}>{fmtDate(t.departureDate)}</td>
                  <td className={td}>{fmtTime(t.departureTime)}</td>
                  <td className={td}>{t.busType}</td>
                  <td className={td}>{t.totalSeats - t.availableSeats}/{t.totalSeats}</td>
                  <td className={td}>{money(t.price, s.currency)}</td>
                  <td className={td}><StatusBadge map={tripStatus} value={t.status} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
