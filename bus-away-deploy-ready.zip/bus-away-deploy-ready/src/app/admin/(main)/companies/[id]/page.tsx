import Link from "next/link";
import { notFound } from "next/navigation";
import { asc, count, eq } from "drizzle-orm";
import { db } from "@/db";
import { bookings, companies, companyAccounts, trips, users } from "@/db/schema";
import { ConfirmButton } from "@/components/client";
import { CompanyForm } from "@/components/company-form";
import { Card, Flash, PageTitle, Row, StatusBadge, btnCls } from "@/components/ui";
import { accountStatus, roleLabel, userStatus } from "@/lib/format";
import { deleteCompanyAction, saveCompanyAction } from "@/app/admin/actions";

export const metadata = { title: "إدارة شركة" };

export default async function AdminCompany({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const { id } = await params;
  const sp = await searchParams;
  const [c] = await db.select().from(companies).where(eq(companies.id, Number(id)));
  if (!c) notFound();
  const accounts = await db.select().from(companyAccounts).where(eq(companyAccounts.companyId, c.id)).orderBy(asc(companyAccounts.id));
  const staff = await db.select().from(users).where(eq(users.companyId, c.id)).orderBy(asc(users.id));
  const [{ t }] = await db.select({ t: count() }).from(trips).where(eq(trips.companyId, c.id));
  const [{ b }] = await db.select({ b: count() }).from(bookings).where(eq(bookings.companyId, c.id));
  return (
    <div className="max-w-4xl space-y-4">
      <Link href="/admin/companies" className="text-sm text-primary">← الشركات</Link>
      <PageTitle title={c.name} subtitle={`${t} رحلة • ${b} حجز`} />
      <Flash sp={sp} />
      <CompanyForm c={c} action={saveCompanyAction} />
      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <h3 className="mb-2 text-sm font-bold">حسابات الدفع</h3>
          {accounts.length === 0 && <p className="text-sm text-slate-400">لا توجد حسابات</p>}
          {accounts.map((a) => (
            <Row key={a.id} k={`${a.paymentType} - ${a.accountName}`} v={<span className="flex items-center gap-2"><span dir="ltr">{a.accountNumber}</span><StatusBadge map={accountStatus} value={a.status} /></span>} />
          ))}
        </Card>
        <Card>
          <h3 className="mb-2 text-sm font-bold">مستخدمو الشركة</h3>
          {staff.length === 0 && <p className="text-sm text-slate-400">لا يوجد مستخدمون</p>}
          {staff.map((u) => (
            <Row key={u.id} k={`${u.name} (${roleLabel[u.role]})`} v={<StatusBadge map={userStatus} value={u.status} />} />
          ))}
        </Card>
      </div>
      <Card>
        <h3 className="mb-2 text-sm font-bold text-red-600">منطقة الخطر</h3>
        <p className="mb-3 text-xs text-slate-500">يمكن إيقاف الشركة من حقل «الحالة» أعلاه. الحذف النهائي ممكن فقط للشركات التي ليس لها رحلات.</p>
        <form action={deleteCompanyAction}>
          <input type="hidden" name="id" value={c.id} />
          <ConfirmButton message="حذف الشركة نهائياً مع حساباتها ومستخدميها؟" className={btnCls("danger")}>حذف الشركة</ConfirmButton>
        </form>
      </Card>
    </div>
  );
}
