import Link from "next/link";
import { asc, count, eq } from "drizzle-orm";
import { db } from "@/db";
import { bookings, companies, trips } from "@/db/schema";
import { Empty, Flash, Logo, PageTitle, StatusBadge, btnCls, td, th } from "@/components/ui";
import { companyStatus } from "@/lib/format";

export const metadata = { title: "الشركات" };

export default async function AdminCompanies({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  const rows = await db.select().from(companies).orderBy(asc(companies.id));
  const tc = await db.select({ id: trips.companyId, c: count() }).from(trips).groupBy(trips.companyId);
  const bc = await db.select({ id: bookings.companyId, c: count() }).from(bookings).groupBy(bookings.companyId);
  void eq;
  return (
    <div className="space-y-4">
      <PageTitle title="إدارة الشركات" subtitle={`${rows.length} شركة مسجلة`} actions={<Link href="/admin/companies/new" className={btnCls()}>＋ إضافة شركة</Link>} />
      <Flash sp={sp} />
      {rows.length === 0 ? (
        <Empty text="لا توجد شركات" icon="🏢" />
      ) : (
        <div className="overflow-x-auto rounded-2xl bg-white ring-1 ring-slate-200">
          <table className="w-full min-w-[800px]">
            <thead><tr>{["الشركة", "الترخيص", "الهاتف", "الخطوط", "الرحلات", "الحجوزات", "الحالة", ""].map((h) => <th key={h} className={th}>{h}</th>)}</tr></thead>
            <tbody className="divide-y divide-slate-100">
              {rows.map((c) => (
                <tr key={c.id} className="hover:bg-slate-50">
                  <td className={td}><div className="flex items-center gap-2"><Logo src={c.logo} name={c.name} size={30} /><b>{c.name}</b></div></td>
                  <td className={td}>{c.licenseNumber ?? "-"}</td>
                  <td className={td} dir="ltr">{c.phone ?? "-"}</td>
                  <td className={`${td} max-w-48 truncate`}>{c.routes ?? "-"}</td>
                  <td className={td}>{tc.find((x) => x.id === c.id)?.c ?? 0}</td>
                  <td className={td}>{bc.find((x) => x.id === c.id)?.c ?? 0}</td>
                  <td className={td}><StatusBadge map={companyStatus} value={c.status} /></td>
                  <td className={td}><Link href={`/admin/companies/${c.id}`} className="font-semibold text-primary">إدارة</Link></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
