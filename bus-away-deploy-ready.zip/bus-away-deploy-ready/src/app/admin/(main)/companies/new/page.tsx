import { CompanyForm } from "@/components/company-form";
import { Flash, PageTitle } from "@/components/ui";
import { saveCompanyAction } from "@/app/admin/actions";

export const metadata = { title: "إضافة شركة" };

export default async function NewCompany({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  return (
    <div className="max-w-3xl">
      <PageTitle title="إضافة شركة" />
      <Flash sp={sp} />
      <CompanyForm action={saveCompanyAction} />
    </div>
  );
}
