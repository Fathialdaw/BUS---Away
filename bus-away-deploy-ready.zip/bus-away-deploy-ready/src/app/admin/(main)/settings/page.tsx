import { FileUpload } from "@/components/client";
import { Card, Field, Flash, PageTitle, btnCls, inputCls } from "@/components/ui";
import { TEMPLATE_META, getSettings } from "@/lib/settings";
import { saveBrandingAction, saveSettingsAction } from "@/app/admin/actions";

export const metadata = { title: "إعدادات النظام" };

export default async function AdminSettings({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  const s = await getSettings();
  return (
    <div className="max-w-3xl space-y-4">
      <PageTitle title="إعدادات النظام" subtitle="تنعكس مباشرة على تطبيق المسافر وبقية التطبيقات" />
      <Flash sp={sp} />
      <Card className="space-y-3">
        <h2 className="text-sm font-bold">الشعار وأيقونة التطبيق</h2>
        <p className="text-xs text-slate-500">اختر الصور من معرض جهازك. تُقص تلقائياً إلى مربع 512×512. الشعار يظهر في رأس التطبيقات وشاشات الدخول، والأيقونة تظهر عند تثبيت تطبيق المسافر على الهاتف وفي تبويب المتصفح (قد يلزم إعادة تثبيت التطبيق لتحديث الأيقونة على الشاشة الرئيسية).</p>
        <form action={saveBrandingAction} className="space-y-3">
          <div className="grid gap-3 sm:grid-cols-2">
            <FileUpload name="app_logo" label="شعار التطبيق" initial={s.app_logo} square={512} removable />
            <FileUpload name="app_icon" label="أيقونة التطبيق" initial={s.app_icon} square={512} removable />
          </div>
          <button className={btnCls()}>حفظ الشعار والأيقونة</button>
        </form>
      </Card>
      <form action={saveSettingsAction} className="space-y-4">
        <Card className="space-y-3">
          <h2 className="text-sm font-bold">هوية التطبيق</h2>
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="اسم التطبيق"><input name="app_name" defaultValue={s.app_name} required className={inputCls} /></Field>
            <Field label="لون الواجهة (تطبيق المسافر)"><input name="primary_color" type="color" defaultValue={s.primary_color} className="h-11 w-full rounded-xl border border-slate-300 bg-white p-1" /></Field>
          </div>
        </Card>
        <Card className="space-y-3">
          <h2 className="text-sm font-bold">بيانات التواصل والعملة</h2>
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="هاتف الدعم"><input name="contact_phone" defaultValue={s.contact_phone} className={inputCls} /></Field>
            <Field label="بريد الدعم"><input name="contact_email" defaultValue={s.contact_email} className={inputCls} /></Field>
            <Field label="العنوان"><input name="contact_address" defaultValue={s.contact_address} className={inputCls} /></Field>
            <Field label="العملة"><input name="currency" defaultValue={s.currency} className={inputCls} /></Field>
            <Field label="مدة الاحتفاظ بالحجز قبل تأكيد الدفع (بالدقائق)"><input name="hold_minutes" type="number" min={1} defaultValue={s.hold_minutes} className={inputCls} /></Field>
          </div>
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" name="employee_chat_allowed" defaultChecked={s.employee_chat_allowed === "true"} />
            السماح لموظفي الشركات بالدخول إلى الدردشة
          </label>
        </Card>
        <Card className="space-y-3">
          <h2 className="text-sm font-bold">الشروط والسياسات</h2>
          <Field label="شروط الاستخدام"><textarea name="terms" rows={5} defaultValue={s.terms} className={inputCls} /></Field>
          <Field label="سياسة الإلغاء والاسترجاع"><textarea name="cancellation_policy" rows={4} defaultValue={s.cancellation_policy} className={inputCls} /></Field>
        </Card>
        <Card className="space-y-3">
          <h2 className="text-sm font-bold">نصوص التنبيهات</h2>
          <p className="text-xs text-slate-500">المتغيرات المتاحة: {"{booking} {route} {date} {time} {seat} {company} {meeting} {note}"}</p>
          {TEMPLATE_META.map((t) => (
            <Field key={t.key} label={t.title}>
              <textarea name={t.key} rows={2} defaultValue={s[t.key]} className={inputCls} />
            </Field>
          ))}
        </Card>
        <button className={btnCls()}>حفظ الإعدادات</button>
      </form>
    </div>
  );
}
