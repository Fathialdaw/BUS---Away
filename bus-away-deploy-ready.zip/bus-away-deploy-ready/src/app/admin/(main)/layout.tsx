import type { ReactNode } from "react";
import { NavLinks, type NavItem } from "@/components/client";
import { ThemeToggle } from "@/components/theme-toggle";
import { Logo } from "@/components/ui";
import { requireAdmin } from "@/lib/auth";
import { getSettings } from "@/lib/settings";
import { adminLogoutAction } from "@/app/admin/actions";

const items: NavItem[] = [
  { href: "/admin", label: "لوحة التحكم", icon: "📊", exact: true },
  { href: "/admin/companies", label: "الشركات", icon: "🏢" },
  { href: "/admin/users", label: "المستخدمون", icon: "👥" },
  { href: "/admin/passengers", label: "الركاب", icon: "🧍" },
  { href: "/admin/trips", label: "الرحلات", icon: "🚌" },
  { href: "/admin/bookings", label: "الحجوزات", icon: "🎫" },
  { href: "/admin/requests", label: "حجز باسم شركة", icon: "📨" },
  { href: "/admin/reports", label: "الرسوم البيانية", icon: "📈" },
  { href: "/admin/settings", label: "إعدادات النظام", icon: "⚙️" },
  { href: "/admin/geo", label: "الولايات والمدن", icon: "🗺️" },
  { href: "/admin/payment-types", label: "طرق الدفع", icon: "💳" },
  { href: "/admin/chat", label: "مراقبة الدردشة", icon: "💬" },
  { href: "/admin/audit", label: "سجل العمليات", icon: "🛡️" },
];

export default async function AdminMain({ children }: { children: ReactNode }) {
  const admin = await requireAdmin();
  const s = await getSettings();
  return (
    <div className="min-h-screen">
      <header className="no-print sticky top-0 z-20 border-b border-slate-200 bg-white">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            <Logo src={s.app_logo} name={s.app_name} size={38} />
            <div>
              <div className="text-sm font-extrabold text-slate-900">{s.app_name}</div>
              <div className="text-[11px] text-slate-500">لوحة مدير النظام</div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <ThemeToggle returnTo="/admin" />
            <span className="hidden text-xs font-semibold text-slate-700 sm:block">{admin.name}</span>
            <form action={adminLogoutAction}>
              <button className="rounded-xl bg-slate-100 px-3 py-2 text-xs font-semibold text-slate-700">خروج</button>
            </form>
          </div>
        </div>
        <div className="px-4 pb-2 lg:hidden">
          <NavLinks items={items} variant="scroll" />
        </div>
      </header>
      <div className="mx-auto flex max-w-7xl gap-6 p-4">
        <aside className="no-print hidden w-56 shrink-0 lg:block">
          <div className="sticky top-20">
            <NavLinks items={items} variant="side" />
          </div>
        </aside>
        <main className="min-w-0 flex-1">{children}</main>
      </div>
    </div>
  );
}
