"use server";

import { and, eq, inArray, ne, or } from "drizzle-orm";
import { db } from "@/db";
import { bookings, notifications, passengers } from "@/db/schema";
import { clearSession, hashPassword, requirePassenger, setSession, verifyPassword } from "@/lib/auth";
import { audit, cancelBooking, createBooking, notifyPassenger, submitPayment } from "@/lib/booking";
import { digits, str } from "@/lib/format";
import { go } from "@/lib/nav";
import { checkOtp, createOtp, normPhone } from "@/lib/otp";

const L = "/passenger/login";

export async function loginAction(fd: FormData): Promise<void> {
  const id = normPhone(str(fd.get("identifier")));
  const pw = str(fd.get("password"));
  const [p] = await db
    .select()
    .from(passengers)
    .where(or(eq(passengers.phone, id), eq(passengers.passengerNumber, id.toUpperCase())));
  if (!p || !verifyPassword(pw, p.password)) go(L, { error: "بيانات الدخول غير صحيحة" });
  if (p.status === "suspended") go(L, { error: "هذا الحساب موقوف، تواصل مع الدعم" });
  if (p.status === "inactive") {
    await createOtp(p.phone, "activate");
    go(`/passenger/verify?phone=${p.phone}&purpose=activate`, { ok: "حسابك غير مفعل، أدخل رمز التفعيل المرسل إليك" });
  }
  await setSession("passenger", p.id);
  await audit({ userId: null, name: p.name, type: "passenger" }, "login", "passenger", p.id);
  go("/passenger");
}

export async function otpLoginRequestAction(fd: FormData): Promise<void> {
  const phone = normPhone(str(fd.get("phone")));
  const [p] = await db.select().from(passengers).where(eq(passengers.phone, phone));
  if (!p) go(L, { error: "رقم الهاتف غير مسجل" });
  if (p.status === "suspended") go(L, { error: "هذا الحساب موقوف" });
  await createOtp(phone, "login");
  go(`/passenger/verify?phone=${phone}&purpose=login`, { ok: "تم إرسال رمز التحقق" });
}

export async function registerAction(fd: FormData): Promise<void> {
  const name = str(fd.get("name"));
  const phone = normPhone(str(fd.get("phone")));
  const pw = str(fd.get("password"));
  const R = "/passenger/register";
  if (name.length < 3) go(R, { error: "أدخل الاسم الكامل" });
  if (!/^\+?\d{9,15}$/.test(phone)) go(R, { error: "رقم الهاتف غير صحيح" });
  if (pw.length < 6) go(R, { error: "كلمة المرور يجب ألا تقل عن 6 أحرف" });
  if (pw !== str(fd.get("confirm"))) go(R, { error: "كلمتا المرور غير متطابقتين" });
  const [ex] = await db.select().from(passengers).where(eq(passengers.phone, phone));
  if (ex) go(R, { error: "رقم الهاتف مسجل مسبقاً، سجل الدخول" });
  let created = false;
  for (let i = 0; i < 5 && !created; i++) {
    try {
      await db.insert(passengers).values({
        passengerNumber: `P${digits(6)}`,
        name,
        phone,
        nationalId: str(fd.get("nationalId")) || null,
        state: str(fd.get("state")) || null,
        city: str(fd.get("city")) || null,
        email: str(fd.get("email")) || null,
        avatar: str(fd.get("avatar")) || null,
        password: hashPassword(pw),
        status: "inactive",
      });
      created = true;
    } catch {
      /* تعارض رقم الراكب - إعادة المحاولة */
    }
  }
  if (!created) go(R, { error: "تعذر إنشاء الحساب، حاول مرة أخرى" });
  await createOtp(phone, "activate");
  go(`/passenger/verify?phone=${phone}&purpose=activate`, { ok: "تم إنشاء الحساب، بانتظار تأكيد الاشتراك" });
}

export async function forgotAction(fd: FormData): Promise<void> {
  const phone = normPhone(str(fd.get("phone")));
  const [p] = await db.select().from(passengers).where(eq(passengers.phone, phone));
  if (p) await createOtp(phone, "reset");
  go(`/passenger/verify?phone=${phone}&purpose=reset`, { ok: "إذا كان الرقم مسجلاً فسيصلك رمز التحقق" });
}

export async function resendAction(fd: FormData): Promise<void> {
  const phone = normPhone(str(fd.get("phone")));
  const purpose = str(fd.get("purpose")) as "activate" | "login" | "reset";
  const [p] = await db.select().from(passengers).where(eq(passengers.phone, phone));
  if (p) await createOtp(phone, purpose);
  go(`/passenger/verify?phone=${phone}&purpose=${purpose}`, { ok: "تم إرسال رمز جديد" });
}

export async function verifyAction(fd: FormData): Promise<void> {
  const phone = normPhone(str(fd.get("phone")));
  const purpose = str(fd.get("purpose"));
  const code = normPhone(str(fd.get("code")));
  const back = `/passenger/verify?phone=${phone}&purpose=${purpose}`;
  const [p] = await db.select().from(passengers).where(eq(passengers.phone, phone));
  if (!p) go(back, { error: "الحساب غير موجود" });
  if (purpose === "reset") {
    const pw = str(fd.get("newPassword"));
    if (pw.length < 6) go(back, { error: "كلمة المرور يجب ألا تقل عن 6 أحرف" });
    if (!(await checkOtp(phone, purpose, code))) go(back, { error: "رمز التحقق غير صحيح أو منتهي" });
    await db.update(passengers).set({ password: hashPassword(pw) }).where(eq(passengers.id, p.id));
    go(L, { ok: "تم تغيير كلمة المرور، سجل الدخول" });
  }
  if (!(await checkOtp(phone, purpose, code))) go(back, { error: "رمز التحقق غير صحيح أو منتهي" });
  if (p.status === "suspended") go(L, { error: "هذا الحساب موقوف" });
  if (p.status === "inactive") {
    await db.update(passengers).set({ status: "active" }).where(eq(passengers.id, p.id));
    await notifyPassenger(p.id, "info", "تم تفعيل حسابك", "مرحباً بك! يمكنك الآن البحث عن الرحلات وحجز مقعدك.");
  }
  await setSession("passenger", p.id);
  go("/passenger", { ok: "تم تأكيد الاشتراك بنجاح" });
}

export async function logoutAction(): Promise<void> {
  await clearSession("passenger");
  go(L);
}

export async function createBookingAction(fd: FormData): Promise<void> {
  const p = await requirePassenger();
  const tripId = Number(str(fd.get("tripId")));
  const seat = Number(str(fd.get("seat")));
  const r = await createBooking({ passengerId: p.id, tripId, seat });
  if (!r.id) go(`/passenger/trips/${tripId}/seats`, { error: r.error ?? "تعذر الحجز" });
  go(`/passenger/booking/${r.id}`, { ok: "تم حجز المقعد مؤقتاً، أكمل الدفع لتأكيد الحجز" });
}

export async function submitPaymentAction(fd: FormData): Promise<void> {
  const p = await requirePassenger();
  const bookingId = Number(str(fd.get("bookingId")));
  const r = await submitPayment({
    bookingId,
    passengerId: p.id,
    accountId: Number(str(fd.get("accountId"))),
    transactionNumber: str(fd.get("transactionNumber")),
    transactionDate: str(fd.get("transactionDate")),
    transactionTime: str(fd.get("transactionTime")),
    receiptImage: str(fd.get("receiptImage")),
  });
  if (r.error) go(`/passenger/booking/${bookingId}/pay`, { error: r.error });
  go(`/passenger/booking/${bookingId}`, { ok: "تم إرسال طلب الحجز، الدفع قيد المراجعة من الشركة" });
}

export async function cancelBookingAction(fd: FormData): Promise<void> {
  const p = await requirePassenger();
  const id = Number(str(fd.get("bookingId")));
  const [b] = await db
    .select()
    .from(bookings)
    .where(and(eq(bookings.id, id), eq(bookings.passengerId, p.id), inArray(bookings.status, ["pending", "awaiting_payment"])));
  if (!b) go("/passenger/tickets", { error: "لا يمكن إلغاء هذا الحجز من التطبيق، تواصل مع الشركة" });
  const r = await cancelBooking(id, { name: p.name, type: "passenger" }, "ألغاه الراكب");
  go("/passenger/tickets?tab=cancelled", r.error ? { error: r.error } : { ok: "تم إلغاء الحجز" });
}

export async function notifAction(fd: FormData): Promise<void> {
  const p = await requirePassenger();
  const op = str(fd.get("op"));
  const id = Number(str(fd.get("id")));
  let back = str(fd.get("returnTo")) || "/passenger";
  if (!back.startsWith("/passenger")) back = "/passenger";
  const own = and(eq(notifications.passengerId, p.id), ne(notifications.id, -1));
  if (op === "read") await db.update(notifications).set({ isRead: true }).where(and(own, eq(notifications.id, id)));
  else if (op === "skip" || op === "dismiss")
    await db.update(notifications).set({ isDismissed: true, isRead: true }).where(and(own, eq(notifications.id, id)));
  else if (op === "readAll")
    await db.update(notifications).set({ isRead: true, isDismissed: true }).where(eq(notifications.passengerId, p.id));
  go(back);
}

export async function updateProfileAction(fd: FormData): Promise<void> {
  const p = await requirePassenger();
  const name = str(fd.get("name"));
  const phone = normPhone(str(fd.get("phone")));
  const P = "/passenger/profile";
  if (name.length < 3) go(P, { error: "أدخل الاسم الكامل" });
  if (!/^\+?\d{9,15}$/.test(phone)) go(P, { error: "رقم الهاتف غير صحيح" });
  if (phone !== p.phone) {
    const [ex] = await db.select().from(passengers).where(eq(passengers.phone, phone));
    if (ex) go(P, { error: "رقم الهاتف مستخدم لحساب آخر" });
  }
  await db
    .update(passengers)
    .set({
      name,
      phone,
      nationalId: str(fd.get("nationalId")) || null,
      state: str(fd.get("state")) || null,
      city: str(fd.get("city")) || null,
      email: str(fd.get("email")) || null,
      avatar: str(fd.get("avatar")) || null,
    })
    .where(eq(passengers.id, p.id));
  go(P, { ok: "تم حفظ البيانات" });
}

export async function changePasswordAction(fd: FormData): Promise<void> {
  const p = await requirePassenger();
  const P = "/passenger/profile";
  if (!verifyPassword(str(fd.get("current")), p.password)) go(P, { error: "كلمة المرور الحالية غير صحيحة" });
  const n = str(fd.get("next"));
  if (n.length < 6) go(P, { error: "كلمة المرور الجديدة قصيرة" });
  if (n !== str(fd.get("confirm"))) go(P, { error: "كلمتا المرور غير متطابقتين" });
  await db.update(passengers).set({ password: hashPassword(n) }).where(eq(passengers.id, p.id));
  go(P, { ok: "تم تغيير كلمة المرور" });
}

export async function deleteAccountAction(fd: FormData): Promise<void> {
  const p = await requirePassenger();
  const P = "/passenger/profile";
  if (!verifyPassword(str(fd.get("password")), p.password)) go(P, { error: "كلمة المرور غير صحيحة" });
  const open = await db
    .select({ id: bookings.id })
    .from(bookings)
    .where(and(eq(bookings.passengerId, p.id), inArray(bookings.status, ["pending", "awaiting_payment", "confirmed"])));
  if (open.length) go(P, { error: "لا يمكن حذف الحساب لوجود حجوزات نشطة. ألغها أو انتظر انتهاء الرحلات" });
  await db
    .update(passengers)
    .set({ name: "حساب محذوف", phone: `deleted-${p.id}-${digits(4)}`, email: null, nationalId: null, avatar: null, status: "suspended", password: hashPassword(digits(12)) })
    .where(eq(passengers.id, p.id));
  await audit({ userId: null, name: p.name, type: "passenger" }, "delete_account", "passenger", p.id);
  await clearSession("passenger");
  go(L, { ok: "تم حذف حسابك" });
}
