import Link from "next/link";
import { notFound } from "next/navigation";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { trips } from "@/db/schema";
import { SeatPicker } from "@/components/client";
import { Flash, PageTitle } from "@/components/ui";
import { requirePassenger } from "@/lib/auth";
import { releaseExpired, seatStates, syncSeats } from "@/lib/booking";
import { fmtDate, fmtTime, money } from "@/lib/format";
import { getSettings } from "@/lib/settings";
import { createBookingAction } from "@/app/passenger/actions";

export const metadata = { title: "اختيار المقعد" };

export default async function SeatsPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const { id } = await params;
  const sp = await searchParams;
  await requirePassenger();
  await releaseExpired();
  const s = await getSettings();
  const [t] = await db.select().from(trips).where(eq(trips.id, Number(id)));
  if (!t) notFound();
  await syncSeats(t.id);
  const states = await seatStates(t.id);
  return (
    <div>
      <Link href={`/passenger/trips/${t.id}`} className="text-sm text-primary">← تفاصيل الرحلة</Link>
      <div className="mt-2" />
      <PageTitle title="اختر مقعدك" subtitle={`${t.fromCity} ← ${t.toCity} • ${fmtDate(t.departureDate)} • ${fmtTime(t.departureTime)}`} />
      <Flash sp={sp} />
      {t.status !== "open" ? (
        <div className="rounded-xl bg-slate-200 p-3 text-center text-sm">الرحلة غير متاحة للحجز</div>
      ) : (
        <SeatPicker total={t.totalSeats} states={states} tripId={t.id} action={createBookingAction} priceLabel={money(t.price, s.currency)} />
      )}
      <p className="mt-3 text-center text-xs text-slate-400">
        المقاعد الخضراء فقط هي المتاحة. المقاعد الأخرى محجوزة من الشركة ولا يمكن اختيارها. يُحجز المقعد مؤقتاً لمدة {s.hold_minutes} دقيقة بعد اختياره لحين إتمام الدفع.
      </p>
    </div>
  );
}
