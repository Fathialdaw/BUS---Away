import { GeoSelect } from "@/components/geo-select";
import { TripCard } from "@/components/trip-card";
import { Card, Empty, btnCls, inputCls, PageTitle } from "@/components/ui";
import { requirePassenger } from "@/lib/auth";
import { releaseExpired } from "@/lib/booking";
import { one, todayStr } from "@/lib/format";
import { getSettings } from "@/lib/settings";
import { getGeo, searchTrips } from "@/lib/trips";

export const metadata = { title: "الرحلات المتاحة" };

export default async function TripsPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  await requirePassenger();
  await releaseExpired();
  const s = await getSettings();
  const geo = await getGeo();
  const from = one(sp.from);
  const to = one(sp.to);
  const date = one(sp.date);
  const companyId = Number(one(sp.company)) || 0;
  let rows = await searchTrips({ from, to, date, limit: 100 });
  if (companyId) rows = rows.filter((r) => r.company.id === companyId);
  return (
    <div className="space-y-4">
      <PageTitle title="الرحلات المتاحة" subtitle={`${rows.length} رحلة`} />
      <Card>
        <form className="grid gap-3 sm:grid-cols-4">
          <GeoSelect name="from" geo={geo} defaultValue={from} placeholder="من (الكل)" />
          <GeoSelect name="to" geo={geo} defaultValue={to} placeholder="إلى (الكل)" />
          <input type="date" name="date" defaultValue={date} min={todayStr()} className={inputCls} />
          <button className={btnCls()}>🔍 بحث</button>
        </form>
      </Card>
      {rows.length === 0 ? (
        <Empty text="لا توجد رحلات مطابقة للبحث" icon="🔎" />
      ) : (
        <div className="grid gap-3 sm:grid-cols-2">
          {rows.map(({ trip, company }) => (
            <TripCard key={trip.id} trip={trip} company={company} currency={s.currency} href={`/passenger/trips/${trip.id}`} />
          ))}
        </div>
      )}
    </div>
  );
}
