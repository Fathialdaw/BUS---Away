import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { notifications } from "@/db/schema";
import { NotificationCard } from "@/components/notif";
import { Empty, PageTitle } from "@/components/ui";
import { requirePassenger } from "@/lib/auth";
import { generateReminders } from "@/lib/booking";
import { notifAction } from "@/app/passenger/actions";

export const metadata = { title: "التنبيهات" };

export default async function NotificationsPage() {
  const p = await requirePassenger();
  await generateReminders(p.id);
  const list = await db.select().from(notifications).where(eq(notifications.passengerId, p.id)).orderBy(desc(notifications.id)).limit(100);
  const unread = list.filter((n) => !n.isRead && !n.isDismissed).length;
  return (
    <div className="space-y-4">
      <PageTitle
        title="التنبيهات"
        subtitle={`${unread} غير مقروء • سجل التنبيهات محفوظ هنا`}
        actions={
          unread > 0 && (
            <form action={notifAction}>
              <input type="hidden" name="op" value="readAll" />
              <input type="hidden" name="returnTo" value="/passenger/notifications" />
              <button className="rounded-lg bg-white px-3 py-1.5 text-xs font-semibold ring-1 ring-slate-300">قراءة الكل</button>
            </form>
          )
        }
      />
      {list.length === 0 ? (
        <Empty text="لا توجد تنبيهات" icon="🔔" />
      ) : (
        <div className="space-y-3">
          {list.map((n) => (
            <NotificationCard key={n.id} n={n} returnTo="/passenger/notifications" />
          ))}
        </div>
      )}
    </div>
  );
}
