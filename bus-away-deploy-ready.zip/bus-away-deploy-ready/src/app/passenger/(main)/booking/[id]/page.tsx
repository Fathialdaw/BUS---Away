import Link from "next/link";
import { notFound } from "next/navigation";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { payments } from "@/db/schema";
import { Card, Flash, PageTitle, Row, StatusBadge, btnCls } from "@/components/ui";
import { requirePassenger } from "@/lib/auth";
import { loadBooking, releaseExpired } from "@/lib/booking";
import { bookingStatus, fmtDate, fmtDateTime, fmtTime, money, paymentStatus } from "@/lib/format";
import { getSettings } from "@/lib/settings";
import { cancelBookingAction } from "@/app/passenger/actions";

export const metadata = { title: "بيانات الحجز" };

export default async function BookingPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const { id } = await params;
  const sp = await searchParams;
  const p = await requirePassenger();
  await releaseExpired();
  const s = await getSettings();
  const tb = await loadBooking(Number(id));
  if (!tb || tb.booking.passengerId !== p.id) notFound();
  const { booking: b, trip: t, company: c } = tb;
  const [pay] = await db.select().from(payments).where(eq(payments.bookingId, b.id)).orderBy(desc(payments.id));
  return (
    <div className="space-y-4">
      <Flash sp={sp} />
      <PageTitle title="مراجعة الحجز" subtitle={`رقم الحجز: ${b.bookingNumber}`} actions={<StatusBadge map={bookingStatus} value={b.status} />} />
      <Card>
        <h3 className="mb-2 text-sm font-bold">بيانات الراكب</h3>
        <Row k="الاسم" v={p.name} />
        <Row k="رقم الراكب" v={p.passengerNumber} />
        <Row k="رقم الهاتف" v={p.phone} />
      </Card>
      <Card>
        <h3 className="mb-2 text-sm font-bold">بيانات الرحلة</h3>
        <Row k="الشركة" v={c.name} />
        <Row k="خط السير" v={`${t.fromCity} ← ${t.toCity}`} />
        <Row k="التاريخ" v={fmtDate(t.departureDate)} />
        <Row k="وقت المغادرة" v={fmtTime(t.departureTime)} />
        <Row k="مكان التجمع" v={t.meetingPoint ?? "-"} />
        <Row k="رقم المقعد" v={<span className="text-lg font-bold text-primary">{b.seatNumber}</span>} />
        <Row k="سعر التذكرة" v={<span className="font-bold">{money(b.price, s.currency)}</span>} />
      </Card>
      {pay && (
        <Card>
          <h3 className="mb-2 text-sm font-bold">بيانات الدفع</h3>
          <Row k="طريقة الدفع" v={pay.paymentMethod} />
          <Row k="رقم العملية" v={pay.transactionNumber ?? "-"} />
          <Row k="التاريخ والوقت" v={`${pay.transactionDate ?? ""} ${pay.transactionTime ?? ""}`} />
          <Row k="حالة الدفع" v={<StatusBadge map={paymentStatus} value={pay.status} />} />
          {pay.note && <Row k="ملاحظة الشركة" v={pay.note} />}
          {pay.receiptImage && (
            <a href={pay.receiptImage} target="_blank" rel="noreferrer" className="mt-3 block">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={pay.receiptImage} alt="إشعار التحويل" className="max-h-56 rounded-xl border object-contain" />
            </a>
          )}
        </Card>
      )}
      {b.status === "pending" && (
        <div className="rounded-xl bg-amber-50 p-3 text-sm text-amber-800">
          ⏳ المقعد محجوز لك مؤقتاً حتى {fmtDateTime(b.expiresAt)}. أكمل الدفع قبل انتهاء المهلة.
        </div>
      )}
      {b.status === "awaiting_payment" && pay?.status === "under_review" && (
        <div className="rounded-xl bg-blue-50 p-3 text-sm text-blue-800">
          🔎 الدفع قيد المراجعة من شركة {c.name}. سيصلك إشعار بالنتيجة، وبعد القبول يصبح الحجز مؤكداً وتصدر التذكرة.
        </div>
      )}
      {b.status === "rejected" && <div className="rounded-xl bg-red-50 p-3 text-sm text-red-700">تم رفض الدفع وتحرير المقعد. {pay?.note}</div>}
      <div className="flex flex-col gap-2">
        {b.status === "pending" && (
          <Link href={`/passenger/booking/${b.id}/pay`} className={`${btnCls()} py-3`}>💳 متابعة إلى الدفع</Link>
        )}
        {b.status === "awaiting_payment" && pay?.status === "needs_edit" && (
          <Link href={`/passenger/booking/${b.id}/pay`} className={`${btnCls("warn")} py-3`}>✏️ تعديل بيانات الدفع</Link>
        )}
        {b.status !== "pending" && ["confirmed", "completed", "no_show"].includes(b.status) && (
          <Link href={`/passenger/tickets/${b.id}`} className={`${btnCls()} py-3`}>🎫 عرض التذكرة</Link>
        )}
        {(b.status === "pending" || b.status === "awaiting_payment") && (
          <form action={cancelBookingAction}>
            <input type="hidden" name="bookingId" value={b.id} />
            <button className={`${btnCls("outline")} w-full text-red-600`}>إلغاء الحجز</button>
          </form>
        )}
      </div>
      <p className="text-center text-xs text-slate-400">{s.cancellation_policy}</p>
    </div>
  );
}
