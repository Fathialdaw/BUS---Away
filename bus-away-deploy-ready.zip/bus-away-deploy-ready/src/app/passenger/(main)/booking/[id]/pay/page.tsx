import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { companyAccounts, payments } from "@/db/schema";
import { FileUpload } from "@/components/client";
import { Card, Field, Flash, PageTitle, Row, btnCls, inputCls } from "@/components/ui";
import { requirePassenger } from "@/lib/auth";
import { loadBooking, releaseExpired } from "@/lib/booking";
import { fmtDate, fmtTime, money, todayStr } from "@/lib/format";
import { getSettings } from "@/lib/settings";
import { submitPaymentAction } from "@/app/passenger/actions";

export const metadata = { title: "الدفع والتحويل" };

export default async function PayPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const { id } = await params;
  const sp = await searchParams;
  const p = await requirePassenger();
  await releaseExpired();
  const s = await getSettings();
  const tb = await loadBooking(Number(id));
  if (!tb || tb.booking.passengerId !== p.id) notFound();
  const { booking: b, trip: t, company: c } = tb;
  const [pay] = await db.select().from(payments).where(eq(payments.bookingId, b.id));
  const editable = b.status === "pending" || (b.status === "awaiting_payment" && pay?.status === "needs_edit");
  if (!editable) redirect(`/passenger/booking/${b.id}`);
  // حسابات الشركة صاحبة الرحلة فقط
  const accounts = await db
    .select()
    .from(companyAccounts)
    .where(and(eq(companyAccounts.companyId, b.companyId), eq(companyAccounts.status, "active")));
  const hhmm = new Intl.DateTimeFormat("en-GB", { hour: "2-digit", minute: "2-digit", timeZone: "Africa/Khartoum" }).format(new Date());
  return (
    <div className="space-y-4">
      <Link href={`/passenger/booking/${b.id}`} className="text-sm text-primary">← مراجعة الحجز</Link>
      <PageTitle title="الدفع والتحويل" subtitle={`${c.name} • ${t.fromCity} ← ${t.toCity}`} />
      <Flash sp={sp} />
      {pay?.note && <div className="rounded-xl bg-amber-50 p-3 text-sm text-amber-800">ملاحظة الشركة: {pay.note}</div>}
      <Card>
        <Row k="رقم الحجز" v={b.bookingNumber} />
        <Row k="الرحلة" v={`${fmtDate(t.departureDate)} - ${fmtTime(t.departureTime)}`} />
        <Row k="المقعد" v={b.seatNumber} />
        <Row k="المبلغ المطلوب" v={<span className="text-xl font-extrabold text-primary">{money(b.price, s.currency)}</span>} />
      </Card>
      {accounts.length === 0 ? (
        <div className="rounded-xl bg-red-50 p-4 text-sm text-red-700">لم تضف هذه الشركة حسابات دفع بعد. تواصل مع الشركة: {c.phone}</div>
      ) : (
        <form action={submitPaymentAction} className="space-y-4">
          <input type="hidden" name="bookingId" value={b.id} />
          <Card>
            <h3 className="mb-3 text-sm font-bold">1) اختر طريقة الدفع وحوّل المبلغ إلى حساب {c.name}</h3>
            <div className="space-y-2">
              {accounts.map((a, i) => (
                <label key={a.id} className="flex cursor-pointer items-start gap-3 rounded-xl border border-slate-200 p-3 has-[:checked]:border-primary has-[:checked]:bg-primary/5">
                  <input type="radio" name="accountId" value={a.id} required defaultChecked={pay ? pay.companyAccountId === a.id : i === 0} className="mt-1" />
                  <div className="text-sm">
                    <div className="font-bold">{a.paymentType}</div>
                    <div className="text-slate-600">صاحب الحساب: {a.accountName}</div>
                    <div className="text-slate-600">رقم الحساب / المحفظة: <b dir="ltr" className="select-all">{a.accountNumber}</b></div>
                    {a.bankName && <div className="text-slate-500">البنك: {a.bankName}</div>}
                  </div>
                </label>
              ))}
            </div>
          </Card>
          <Card className="space-y-3">
            <h3 className="text-sm font-bold">2) أدخل بيانات العملية وأرفق الإشعار</h3>
            <Field label="رقم العملية *">
              <input name="transactionNumber" required defaultValue={pay?.transactionNumber ?? ""} className={inputCls} />
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="تاريخ العملية">
                <input type="date" name="transactionDate" defaultValue={pay?.transactionDate ?? todayStr()} className={inputCls} />
              </Field>
              <Field label="وقت العملية">
                <input type="time" name="transactionTime" defaultValue={pay?.transactionTime ?? hhmm} className={inputCls} />
              </Field>
            </div>
            <FileUpload name="receiptImage" label="صورة إشعار التحويل *" initial={pay?.receiptImage} />
          </Card>
          <button className={`${btnCls()} w-full py-3 text-base`}>إرسال طلب الحجز</button>
        </form>
      )}
    </div>
  );
}
