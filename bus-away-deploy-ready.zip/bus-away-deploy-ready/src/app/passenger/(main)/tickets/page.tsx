import Link from "next/link";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { bookings, companies, payments, trips } from "@/db/schema";
import { Empty, StatusBadge, PageTitle, Flash, cx } from "@/components/ui";
import { requirePassenger } from "@/lib/auth";
import { releaseExpired } from "@/lib/booking";
import { bookingStatus, depAt, fmtDate, fmtTime, money, one, paymentStatus } from "@/lib/format";
import { getSettings } from "@/lib/settings";

export const metadata = { title: "التذاكر والحجوزات" };

const TABS = [
  ["current", "الحالية"],
  ["review", "قيد المراجعة"],
  ["past", "السابقة"],
  ["cancelled", "ملغاة / مرفوضة"],
] as const;

export default async function TicketsPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  const p = await requirePassenger();
  await releaseExpired();
  const s = await getSettings();
  const tab = one(sp.tab) || "current";
  const rows = await db
    .select({ b: bookings, t: trips, c: companies, pay: payments })
    .from(bookings)
    .innerJoin(trips, eq(trips.id, bookings.tripId))
    .innerJoin(companies, eq(companies.id, bookings.companyId))
    .leftJoin(payments, eq(payments.bookingId, bookings.id))
    .where(eq(bookings.passengerId, p.id))
    .orderBy(desc(bookings.id));
  const now = new Date();
  const kind = (r: (typeof rows)[number]) => {
    if (["cancelled", "rejected"].includes(r.b.status)) return "cancelled";
    if (["pending", "awaiting_payment"].includes(r.b.status)) return "review";
    const past = depAt(r.t.departureDate, r.t.departureTime) < now;
    if (["completed", "no_show"].includes(r.b.status) || past) return "past";
    return "current";
  };
  const list = rows.filter((r) => kind(r) === tab);
  return (
    <div className="space-y-4">
      <PageTitle title="التذاكر والحجوزات" />
      <Flash sp={sp} />
      <div className="flex gap-2 overflow-x-auto">
        {TABS.map(([k, label]) => (
          <Link key={k} href={`/passenger/tickets?tab=${k}`} className={cx("whitespace-nowrap rounded-full px-4 py-1.5 text-sm font-semibold", tab === k ? "bg-primary text-white" : "bg-white text-slate-600 ring-1 ring-slate-200")}>
            {label} ({rows.filter((r) => kind(r) === k).length})
          </Link>
        ))}
      </div>
      {list.length === 0 ? (
        <Empty text="لا توجد حجوزات في هذا القسم" icon="🎫" />
      ) : (
        <div className="space-y-3">
          {list.map(({ b, t, c, pay }) => (
            <div key={b.id} className="rounded-2xl bg-white p-4 shadow-sm ring-1 ring-slate-200">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="font-bold">{t.fromCity} ← {t.toCity}</div>
                  <div className="mt-0.5 text-xs text-slate-500">{c.name}</div>
                </div>
                <StatusBadge map={bookingStatus} value={b.status} />
              </div>
              <div className="mt-2 grid grid-cols-2 gap-1 text-xs text-slate-500">
                <span>📅 {fmtDate(t.departureDate)}</span>
                <span>🕗 {fmtTime(t.departureTime)}</span>
                <span>💺 مقعد {b.seatNumber}</span>
                <span>💵 {money(b.price, s.currency)}</span>
                <span className="col-span-2">🔖 {b.bookingNumber}</span>
              </div>
              {pay && (
                <div className="mt-2 flex items-center gap-2 text-xs">
                  <span className="text-slate-500">الدفع:</span>
                  <StatusBadge map={paymentStatus} value={pay.status} />
                  {pay.receiptImage && (
                    <a href={pay.receiptImage} target="_blank" rel="noreferrer" className="mr-auto text-primary">🧾 صورة الإشعار</a>
                  )}
                </div>
              )}
              <div className="mt-3 flex gap-2">
                <Link href={`/passenger/booking/${b.id}`} className="rounded-lg bg-slate-100 px-3 py-1.5 text-xs font-semibold">تفاصيل الحجز</Link>
                {["confirmed", "completed", "no_show"].includes(b.status) && (
                  <Link href={`/passenger/tickets/${b.id}`} className="rounded-lg bg-primary px-3 py-1.5 text-xs font-semibold text-white">عرض التذكرة</Link>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
