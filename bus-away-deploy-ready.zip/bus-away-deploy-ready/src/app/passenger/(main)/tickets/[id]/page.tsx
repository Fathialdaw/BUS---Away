import Link from "next/link";
import { notFound } from "next/navigation";
import { PrintButton } from "@/components/client";
import { TicketView } from "@/components/ticket";
import { requirePassenger } from "@/lib/auth";
import { getTicketData } from "@/lib/booking";
import { getSettings } from "@/lib/settings";

export const metadata = { title: "التذكرة الإلكترونية" };

export default async function TicketPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const p = await requirePassenger();
  const s = await getSettings();
  const d = await getTicketData(Number(id));
  if (!d || d.booking.passengerId !== p.id) notFound();
  return (
    <div className="space-y-4">
      <Link href="/passenger/tickets" className="no-print text-sm text-primary">← التذاكر</Link>
      <TicketView d={d} s={s} />
      <div className="no-print flex justify-center">
        <PrintButton label="⬇️ تحميل / طباعة التذكرة" />
      </div>
    </div>
  );
}
