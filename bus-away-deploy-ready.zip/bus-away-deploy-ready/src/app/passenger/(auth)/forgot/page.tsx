import Link from "next/link";
import { AuthShell } from "@/components/auth-shell";
import { Field, Flash, btnCls, inputCls } from "@/components/ui";
import { forgotAction } from "../../actions";

export const metadata = { title: "نسيت كلمة المرور" };

export default async function ForgotPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  return (
    <AuthShell title="نسيت كلمة المرور" subtitle="أدخل رقم هاتفك لإرسال رمز التحقق" badge="تطبيق المسافر">
      <Flash sp={sp} />
      <form action={forgotAction} className="space-y-4">
        <Field label="رقم الهاتف">
          <input name="phone" required inputMode="tel" className={inputCls} />
        </Field>
        <button className={`${btnCls()} w-full`}>إرسال الرمز</button>
      </form>
      <p className="mt-4 text-center text-sm">
        <Link href="/passenger/login" className="text-primary">العودة لتسجيل الدخول</Link>
      </p>
    </AuthShell>
  );
}
