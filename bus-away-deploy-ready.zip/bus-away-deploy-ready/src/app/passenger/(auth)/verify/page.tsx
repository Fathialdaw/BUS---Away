import { AuthShell } from "@/components/auth-shell";
import { Field, Flash, btnCls, inputCls } from "@/components/ui";
import { one } from "@/lib/format";
import { latestOtp, normPhone } from "@/lib/otp";
import { resendAction, verifyAction } from "../../actions";

export const metadata = { title: "رمز التحقق" };

const TITLES: Record<string, string> = {
  activate: "تأكيد الاشتراك",
  login: "تسجيل الدخول برمز التحقق",
  reset: "استعادة كلمة المرور",
};

export default async function VerifyPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  const phone = normPhone(one(sp.phone));
  const purpose = one(sp.purpose) || "activate";
  const demo = await latestOtp(phone, purpose);
  return (
    <AuthShell title={TITLES[purpose] ?? "رمز التحقق"} subtitle={`أدخل الرمز المكوّن من 6 أرقام المرسل إلى ${phone}`} badge="تطبيق المسافر">
      <Flash sp={sp} />
      {demo && (
        <div className="mb-4 rounded-xl border border-amber-200 bg-amber-50 p-3 text-center">
          <div className="text-xs text-amber-700">وضع التجربة — لا توجد بوابة رسائل SMS مفعّلة، رمزك هو:</div>
          <div className="mt-1 font-mono text-2xl font-bold tracking-[0.4em] text-amber-900">{demo}</div>
        </div>
      )}
      <form action={verifyAction} className="space-y-4">
        <input type="hidden" name="phone" value={phone} />
        <input type="hidden" name="purpose" value={purpose} />
        <Field label="رمز التحقق">
          <input name="code" required inputMode="numeric" maxLength={6} className={`${inputCls} text-center font-mono text-lg tracking-widest`} />
        </Field>
        {purpose === "reset" && (
          <Field label="كلمة المرور الجديدة">
            <input name="newPassword" type="password" minLength={6} required className={inputCls} />
          </Field>
        )}
        <button className={`${btnCls()} w-full`}>تأكيد</button>
      </form>
      <form action={resendAction} className="mt-3 text-center">
        <input type="hidden" name="phone" value={phone} />
        <input type="hidden" name="purpose" value={purpose} />
        <button className="text-sm text-primary">إعادة إرسال الرمز</button>
      </form>
    </AuthShell>
  );
}
