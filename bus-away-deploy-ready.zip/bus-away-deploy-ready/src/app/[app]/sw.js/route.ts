const SW = `
const CACHE = "app-shell-v1";
const OFFLINE = '<!doctype html><html lang="ar" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>لا يوجد اتصال</title><body style="font-family:sans-serif;display:grid;place-items:center;min-height:100vh;background:#f1f5f9;color:#334155;text-align:center"><div><div style="font-size:48px">📡</div><h2>لا يوجد اتصال بالإنترنت</h2><p>تحقق من الشبكة ثم أعد المحاولة.</p><button onclick="location.reload()" style="padding:10px 20px;border-radius:12px;border:0;background:#1d4ed8;color:#fff;font-size:16px">إعادة المحاولة</button></div></body></html>';
self.addEventListener("install", (e) => { self.skipWaiting(); });
self.addEventListener("activate", (e) => { e.waitUntil(self.clients.claim()); });
self.addEventListener("fetch", (e) => {
  const req = e.request;
  if (req.method !== "GET") return;
  if (req.mode === "navigate") {
    e.respondWith(fetch(req).catch(() => new Response(OFFLINE, { headers: { "content-type": "text/html; charset=utf-8" } })));
    return;
  }
  const url = new URL(req.url);
  if (url.pathname.startsWith("/_next/static/") || url.pathname.startsWith("/icons/")) {
    e.respondWith(caches.open(CACHE).then(async (c) => {
      const hit = await c.match(req);
      if (hit) return hit;
      const res = await fetch(req);
      if (res.ok) c.put(req, res.clone());
      return res;
    }));
  }
});
`;

export async function GET(_req: Request, ctx: { params: Promise<{ app: string }> }) {
  const { app } = await ctx.params;
  if (!["passenger", "company", "admin"].includes(app)) return new Response("Not found", { status: 404 });
  return new Response(SW, {
    headers: { "content-type": "application/javascript; charset=utf-8", "cache-control": "no-cache" },
  });
}
