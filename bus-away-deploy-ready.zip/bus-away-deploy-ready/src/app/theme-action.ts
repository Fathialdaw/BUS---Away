"use server";

import { cookies } from "next/headers";
import { redirect } from "next/navigation";

export async function toggleThemeAction(returnTo: string): Promise<void> {
  const c = await cookies();
  const next = c.get("theme")?.value === "dark" ? "light" : "dark";
  c.set("theme", next, { path: "/", maxAge: 60 * 60 * 24 * 365, sameSite: "lax" });
  redirect(returnTo.startsWith("/") ? returnTo : "/");
}
