import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import { cookies } from "next/headers";
import { getSettings } from "@/lib/settings";
import "./globals.css";

export const dynamic = "force-dynamic";

export async function generateMetadata(): Promise<Metadata> {
  const s = await getSettings();
  return {
    title: { default: s.app_name, template: `%s | ${s.app_name}` },
    icons: { icon: "/favicon.ico", apple: "/icons/apple-touch-icon.png" },
    description: "نظام حجز السفر بالبصات - تطبيق المسافر، تطبيق إدارة الشركات، وتطبيق مدير النظام",
  };
}

export const viewport: Viewport = {
  themeColor: "#0f5c3a",
  width: "device-width",
  initialScale: 1,
};

export default async function RootLayout({ children }: { children: ReactNode }) {
  const c = await cookies();
  const dark = c.get("theme")?.value === "dark";
  return (
    <html lang="ar" dir="rtl" className={dark ? "dark" : undefined}>
      <body className="min-h-screen antialiased">{children}</body>
    </html>
  );
}
