import type { Metadata, Viewport } from "next";
import type { CSSProperties, ReactNode } from "react";
import { InstallPrompt } from "@/components/client";
import { getSettings } from "@/lib/settings";

export async function generateMetadata(): Promise<Metadata> {
  const s = await getSettings();
  return {
    title: { default: `إدارة الشركات | ${s.app_name}`, template: `%s | إدارة الشركات` },
    manifest: "/company/manifest.webmanifest",
    applicationName: `${s.app_name} - إدارة الشركات`,
    appleWebApp: { capable: true, title: "إدارة الشركات", statusBarStyle: "default" },
    icons: { icon: "/icons/company-512.png", apple: "/icons/company-512.png" },
  };
}

export const viewport: Viewport = { themeColor: "#0f766e", width: "device-width", initialScale: 1 };

export default function CompanyLayout({ children }: { children: ReactNode }) {
  return (
    <div style={{ "--primary": "#0f766e" } as CSSProperties} className="min-h-screen">
      <InstallPrompt app="company" label="تطبيق إدارة الشركات" />
      {children}
    </div>
  );
}
