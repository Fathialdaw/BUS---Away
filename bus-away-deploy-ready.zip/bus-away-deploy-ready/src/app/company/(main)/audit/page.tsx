import { redirect } from "next/navigation";
import { go } from "@/lib/nav";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { auditLogs } from "@/db/schema";
import { Empty, PageTitle, td, th } from "@/components/ui";
import { isManager, requireCompany } from "@/lib/auth";
import { fmtDateTime } from "@/lib/format";

export const metadata = { title: "سجل العمليات" };

export default async function CompanyAudit() {
  const { user, company } = await requireCompany();
  if (!isManager(user)) go("/company", { error: "هذه الصفحة لمدير المكتب فقط" });
  const rows = await db.select().from(auditLogs).where(eq(auditLogs.companyId, company.id)).orderBy(desc(auditLogs.id)).limit(150);
  return (
    <div className="space-y-4">
      <PageTitle title="سجل العمليات" subtitle="آخر 150 عملية على بيانات شركتك" />
      {rows.length === 0 ? (
        <Empty text="لا توجد عمليات" icon="🛡️" />
      ) : (
        <div className="overflow-x-auto rounded-2xl bg-white ring-1 ring-slate-200">
          <table className="w-full min-w-[640px]">
            <thead><tr>{["الوقت", "المنفذ", "العملية", "الكيان"].map((h) => <th key={h} className={th}>{h}</th>)}</tr></thead>
            <tbody className="divide-y divide-slate-100">
              {rows.map((l) => (
                <tr key={l.id}>
                  <td className={td}>{fmtDateTime(l.createdAt)}</td>
                  <td className={td}>{l.actorName}</td>
                  <td className={`${td} font-mono text-xs`}>{l.action}</td>
                  <td className={td}>{l.entityType} {l.entityId ? `#${l.entityId}` : ""}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
