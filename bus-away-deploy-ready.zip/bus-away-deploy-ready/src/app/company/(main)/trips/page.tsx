import Link from "next/link";
import { redirect } from "next/navigation";
import { go } from "@/lib/nav";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { trips } from "@/db/schema";
import { Empty, Flash, PageTitle, StatusBadge, btnCls, td, th } from "@/components/ui";
import { ConfirmButton } from "@/components/client";
import { can, isManager, requireCompany } from "@/lib/auth";
import { releaseExpired } from "@/lib/booking";
import { fmtDate, fmtTime, money, tripStatus } from "@/lib/format";
import { getSettings } from "@/lib/settings";
import { cancelTripAction, deleteTripAction } from "@/app/company/actions";

export const metadata = { title: "الرحلات" };

export default async function CompanyTrips({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  const { user, company } = await requireCompany();
  if (!can(user, "trips")) go("/company", { error: "لا تملك صلاحية عرض الرحلات" });
  await releaseExpired();
  const s = await getSettings();
  const m = isManager(user);
  const rows = await db.select().from(trips).where(eq(trips.companyId, company.id)).orderBy(desc(trips.departureDate), desc(trips.departureTime));
  return (
    <div className="space-y-4">
      <PageTitle title="الرحلات" subtitle={`${rows.length} رحلة تابعة لـ ${company.name}`} actions={m && <Link href="/company/trips/new" className={btnCls()}>＋ إضافة رحلة</Link>} />
      <Flash sp={sp} />
      {rows.length === 0 ? (
        <Empty text="لا توجد رحلات" icon="🚌" />
      ) : (
        <div className="overflow-x-auto rounded-2xl bg-white shadow-sm ring-1 ring-slate-200">
          <table className="w-full min-w-[900px]">
            <thead>
              <tr>{["الخط", "التاريخ", "المغادرة", "الوصول", "البص", "المقاعد", "السعر", "الحالة", ""].map((h) => <th key={h} className={th}>{h}</th>)}</tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {rows.map((t) => (
                <tr key={t.id} className="hover:bg-slate-50">
                  <td className={`${td} font-semibold`}>{t.fromCity} ← {t.toCity}</td>
                  <td className={td}>{fmtDate(t.departureDate)}</td>
                  <td className={td}>{fmtTime(t.departureTime)}</td>
                  <td className={td}>{fmtTime(t.arrivalTime)}</td>
                  <td className={td}>{t.busType}</td>
                  <td className={td}>{t.totalSeats - t.availableSeats}/{t.totalSeats}</td>
                  <td className={td}>{money(t.price, s.currency)}</td>
                  <td className={td}><StatusBadge map={tripStatus} value={t.status} /></td>
                  <td className={td}>
                    {m && (
                      <div className="flex items-center gap-2">
                        <Link href={`/company/trips/${t.id}`} className="text-xs font-semibold text-primary">تعديل</Link>
                        <Link href={`/company/trips/${t.id}/seats`} className="text-xs font-semibold text-emerald-600">المقاعد</Link>
                        {!["cancelled", "ended"].includes(t.status) && (
                          <form action={cancelTripAction}>
                            <input type="hidden" name="id" value={t.id} />
                            <ConfirmButton message="سيتم إلغاء الرحلة وجميع حجوزاتها وإشعار الركاب. متابعة؟" className="cursor-pointer text-xs font-semibold text-amber-600">إلغاء</ConfirmButton>
                          </form>
                        )}
                        <form action={deleteTripAction}>
                          <input type="hidden" name="id" value={t.id} />
                          <ConfirmButton message="حذف الرحلة نهائياً؟" className="cursor-pointer text-xs font-semibold text-red-600">حذف</ConfirmButton>
                        </form>
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
