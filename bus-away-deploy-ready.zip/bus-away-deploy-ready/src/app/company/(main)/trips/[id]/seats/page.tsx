import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { trips } from "@/db/schema";
import { ManagerSeatMap } from "@/components/manager-seat-map";
import { Card, Flash, PageTitle } from "@/components/ui";
import { can, isManager, requireCompany } from "@/lib/auth";
import { seatStates, syncSeats } from "@/lib/booking";
import { fmtDate, fmtTime } from "@/lib/format";

export const metadata = { title: "إدارة المقاعد" };

export default async function TripSeatsPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const { id } = await params;
  const sp = await searchParams;
  const { user, company } = await requireCompany();
  if (!isManager(user) && !can(user, "trips")) redirect("/company?error=لا تملك صلاحية إدارة المقاعد");
  const tripId = Number(id);
  const [t] = await db.select().from(trips).where(and(eq(trips.id, tripId), eq(trips.companyId, company.id)));
  if (!t) notFound();
  await syncSeats(tripId);
  const states = await seatStates(tripId);
  const openCount = states.filter((s) => s.state === "open").length;
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <Link href="/company/trips" className="text-sm text-primary">← الرحلات</Link>
        <div className="flex gap-2">
          <Link href={`/company/trips/${t.id}`} className="rounded-lg bg-white px-3 py-1.5 text-xs font-semibold ring-1 ring-slate-300">تعديل الرحلة</Link>
        </div>
      </div>
      <PageTitle
        title="إدارة مقاعد الرحلة"
        subtitle={`${t.fromCity} ← ${t.toCity} • ${fmtDate(t.departureDate)} • ${fmtTime(t.departureTime)}`}
      />
      <Flash sp={sp} />
      <Card>
        <p className="text-sm leading-7 text-slate-600">
          <b>قاعدة العمل:</b> يفتح المدير أو الموظف المقاعد التي تريد بيعها عبر التطبيق فقط، وتظهر <b>كل المقاعد غير المختارة (المحظورة)</b> للركاب كمحجوزة ولا يمكن اختيارها.
          مثلاً: إذا بعتَ المقعد 15 فقط عبر التطبيق، ابقه مفتوحاً وحبّر/احظر بقية المقاعد.
          {openCount === 0 && (
            <span className="mt-2 block rounded-xl bg-amber-50 p-2 font-semibold text-amber-800">
              ⚠️ لا توجد مقاعد مفتوحة حالياً — الركاب لا يمكنهم الحجز في هذه الرحلة. اضغط «فتح جميع المقاعد» ثم احظر ما بعتَه يدوياً.
            </span>
          )}
        </p>
      </Card>
      <ManagerSeatMap tripId={t.id} total={t.totalSeats} states={states} />
    </div>
  );
}
