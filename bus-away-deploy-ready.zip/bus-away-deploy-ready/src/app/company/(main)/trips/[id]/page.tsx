import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { trips } from "@/db/schema";
import { btnCls, Flash, PageTitle } from "@/components/ui";
import { TripForm } from "@/components/trip-form";
import { isManager, requireCompany } from "@/lib/auth";
import { getGeo } from "@/lib/trips";
import { saveTripAction } from "@/app/company/actions";

export const metadata = { title: "تعديل رحلة" };

export default async function EditTrip({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const { id } = await params;
  const sp = await searchParams;
  const { user, company } = await requireCompany();
  if (!isManager(user)) redirect("/company/trips");
  const [t] = await db.select().from(trips).where(and(eq(trips.id, Number(id)), eq(trips.companyId, company.id)));
  if (!t) notFound();
  const geo = await getGeo();
  return (
    <div>
      <PageTitle
        title="تعديل الرحلة"
        subtitle={`${t.fromCity} ← ${t.toCity}`}
        actions={<Link href={`/company/trips/${t.id}/seats`} className={btnCls("outline", true)}>💺 إدارة المقاعد</Link>}
      />
      <Flash sp={sp} />
      <TripForm trip={t} geo={geo} action={saveTripAction} />
    </div>
  );
}
