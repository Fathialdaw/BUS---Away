import { redirect } from "next/navigation";
import { go } from "@/lib/nav";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { expenses, trips } from "@/db/schema";
import { ConfirmButton } from "@/components/client";
import { Card, Empty, Field, Flash, PageTitle, StatCard, btnCls, inputCls, td, th } from "@/components/ui";
import { isManager, requireCompany } from "@/lib/auth";
import { fmtDate, money, todayStr } from "@/lib/format";
import { getSettings } from "@/lib/settings";
import { addExpenseAction, deleteExpenseAction } from "@/app/company/actions";

export const metadata = { title: "المصروفات" };

export default async function ExpensesPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  const { user, company } = await requireCompany();
  if (!isManager(user)) go("/company", { error: "هذه الصفحة لمدير المكتب فقط" });
  const s = await getSettings();
  const rows = await db.select({ e: expenses, t: trips }).from(expenses).leftJoin(trips, eq(trips.id, expenses.tripId)).where(eq(expenses.companyId, company.id)).orderBy(desc(expenses.expenseDate), desc(expenses.id)).limit(200);
  const myTrips = await db.select().from(trips).where(eq(trips.companyId, company.id)).orderBy(desc(trips.departureDate)).limit(60);
  const total = rows.reduce((a, r) => a + r.e.amount, 0);
  return (
    <div className="space-y-4">
      <PageTitle title="المصروفات" subtitle="تُحتسب في تقارير الشركة" />
      <Flash sp={sp} />
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <StatCard icon="🧾" label="إجمالي المصروفات" value={money(total, s.currency)} />
        <StatCard icon="📄" label="عدد البنود" value={rows.length} />
      </div>
      <Card>
        <form action={addExpenseAction} className="grid gap-3 sm:grid-cols-5">
          <Field label="البيان"><input name="title" required className={inputCls} /></Field>
          <Field label="المبلغ"><input name="amount" type="number" min={1} required className={inputCls} /></Field>
          <Field label="التاريخ"><input name="date" type="date" defaultValue={todayStr()} className={inputCls} /></Field>
          <Field label="الرحلة (اختياري)">
            <select name="tripId" className={inputCls}>
              <option value="">-</option>
              {myTrips.map((t) => <option key={t.id} value={t.id}>{t.fromCity} ← {t.toCity} ({t.departureDate})</option>)}
            </select>
          </Field>
          <div className="flex items-end"><button className={`${btnCls()} w-full`}>إضافة</button></div>
        </form>
      </Card>
      {rows.length === 0 ? (
        <Empty text="لا توجد مصروفات" icon="🧾" />
      ) : (
        <div className="overflow-x-auto rounded-2xl bg-white ring-1 ring-slate-200">
          <table className="w-full min-w-[600px]">
            <thead><tr>{["التاريخ", "البيان", "الرحلة", "المبلغ", ""].map((h) => <th key={h} className={th}>{h}</th>)}</tr></thead>
            <tbody className="divide-y divide-slate-100">
              {rows.map(({ e, t }) => (
                <tr key={e.id}>
                  <td className={td}>{fmtDate(e.expenseDate)}</td>
                  <td className={td}>{e.title}</td>
                  <td className={td}>{t ? `${t.fromCity} ← ${t.toCity}` : "-"}</td>
                  <td className={`${td} font-semibold`}>{money(e.amount, s.currency)}</td>
                  <td className={td}>
                    <form action={deleteExpenseAction}>
                      <input type="hidden" name="id" value={e.id} />
                      <ConfirmButton message="حذف المصروف؟" className="cursor-pointer text-xs font-semibold text-red-600">حذف</ConfirmButton>
                    </form>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
