import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { and, asc, eq, ne } from "drizzle-orm";
import { db } from "@/db";
import { chatMembers, chatRooms, companies, messages, users } from "@/db/schema";
import { AutoRefresh, FileUpload } from "@/components/client";
import { Card, Flash, btnCls, inputCls } from "@/components/ui";
import { isManager, requireCompany } from "@/lib/auth";
import { fmtDateTime } from "@/lib/format";
import { getSettings } from "@/lib/settings";
import { reportMessageAction, sendMessageAction } from "@/app/company/actions";

export const metadata = { title: "محادثة" };

export default async function ChatRoom({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const { id } = await params;
  const sp = await searchParams;
  const { user } = await requireCompany();
  const s = await getSettings();
  if (!isManager(user) && s.employee_chat_allowed !== "true") redirect("/company");
  const roomId = Number(id);
  const [mem] = await db.select().from(chatMembers).where(and(eq(chatMembers.roomId, roomId), eq(chatMembers.userId, user.id)));
  if (!mem) notFound();
  const [room] = await db.select().from(chatRooms).where(eq(chatRooms.id, roomId));
  const members = await db
    .select({ uid: users.id, name: users.name, company: companies.name })
    .from(chatMembers)
    .innerJoin(users, eq(users.id, chatMembers.userId))
    .leftJoin(companies, eq(companies.id, users.companyId))
    .where(eq(chatMembers.roomId, roomId));
  const msgs = await db
    .select({ m: messages, name: users.name })
    .from(messages)
    .innerJoin(users, eq(users.id, messages.senderId))
    .where(eq(messages.roomId, roomId))
    .orderBy(asc(messages.id))
    .limit(300);
  await db.update(messages).set({ isRead: true }).where(and(eq(messages.roomId, roomId), ne(messages.senderId, user.id)));
  const other = members.find((m) => m.uid !== user.id);
  const title = room.isGroup ? room.name : `${other?.name} — ${other?.company}`;
  return (
    <div className="space-y-3">
      <AutoRefresh seconds={8} />
      <Link href="/company/chat" className="text-sm text-primary">← المحادثات</Link>
      <Card>
        <div className="font-bold">{room.isGroup ? "👥" : "💬"} {title}</div>
        {room.isGroup && <div className="text-xs text-slate-500">{members.map((m) => `${m.name} (${m.company})`).join("، ")}</div>}
      </Card>
      <Flash sp={sp} />
      <div className="max-h-[55vh] min-h-48 space-y-2 overflow-y-auto rounded-2xl bg-slate-50 p-3 ring-1 ring-slate-200">
        {msgs.length === 0 && <p className="py-8 text-center text-sm text-slate-400">ابدأ المحادثة...</p>}
        {msgs.map(({ m, name }) => {
          const mine = m.senderId === user.id;
          return (
            <div key={m.id} className={`flex ${mine ? "justify-start" : "justify-end"}`}>
              <div className={`max-w-[80%] rounded-2xl px-3 py-2 text-sm ${mine ? "bg-primary text-white" : "bg-white ring-1 ring-slate-200"}`}>
                {!mine && <div className="mb-0.5 text-[11px] font-bold text-primary">{name}</div>}
                {m.message && <p className="whitespace-pre-wrap">{m.message}</p>}
                {m.attachment && (
                  <a href={m.attachment} target="_blank" rel="noreferrer" className="mt-1 block text-xs underline">📎 مرفق</a>
                )}
                <div className={`mt-1 flex items-center justify-between gap-3 text-[10px] ${mine ? "text-white/70" : "text-slate-400"}`}>
                  <span>{fmtDateTime(m.createdAt)}</span>
                  {m.reported ? (
                    <span>🚩 تم الإبلاغ</span>
                  ) : (
                    !mine && (
                      <form action={reportMessageAction}>
                        <input type="hidden" name="id" value={m.id} />
                        <input type="hidden" name="reason" value="محتوى مخالف" />
                        <button className="cursor-pointer underline">إبلاغ</button>
                      </form>
                    )
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
      <form action={sendMessageAction} className="space-y-2 rounded-2xl bg-white p-3 ring-1 ring-slate-200">
        <input type="hidden" name="roomId" value={roomId} />
        <textarea name="message" rows={2} placeholder="اكتب رسالتك..." className={inputCls} />
        <details>
          <summary className="cursor-pointer text-xs text-slate-500">📎 إرفاق ملف</summary>
          <div className="mt-2"><FileUpload name="attachment" label="المرفق (صورة أو PDF)" accept="image/*,application/pdf" /></div>
        </details>
        <button className={btnCls()}>إرسال</button>
      </form>
    </div>
  );
}
