import { redirect } from "next/navigation";
import { go } from "@/lib/nav";
import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { companyAccounts, paymentTypes } from "@/db/schema";
import { ConfirmButton } from "@/components/client";
import { Card, Empty, Field, Flash, PageTitle, StatusBadge, btnCls, inputCls } from "@/components/ui";
import { isManager, requireCompany } from "@/lib/auth";
import { accountStatus } from "@/lib/format";
import { deleteAccountAction, saveAccountAction, toggleAccountAction } from "@/app/company/actions";

export const metadata = { title: "حسابات الدفع" };

export default async function AccountsPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  const { user, company } = await requireCompany();
  if (!isManager(user)) go("/company", { error: "هذه الصفحة لمدير المكتب فقط" });
  const types = await db.select().from(paymentTypes).where(eq(paymentTypes.active, true)).orderBy(asc(paymentTypes.id));
  const rows = await db.select().from(companyAccounts).where(eq(companyAccounts.companyId, company.id)).orderBy(asc(companyAccounts.id));
  const fields = (a?: (typeof rows)[number]) => (
    <div className="grid gap-3 sm:grid-cols-2">
      <Field label="نوع الحساب">
        <select name="paymentType" defaultValue={a?.paymentType} className={inputCls} required>
          {types.map((t) => <option key={t.id}>{t.name}</option>)}
        </select>
      </Field>
      <Field label="اسم صاحب الحساب"><input name="accountName" defaultValue={a?.accountName} required className={inputCls} /></Field>
      <Field label="رقم الحساب / المحفظة"><input name="accountNumber" defaultValue={a?.accountNumber} required dir="ltr" className={inputCls} /></Field>
      <Field label="اسم البنك"><input name="bankName" defaultValue={a?.bankName ?? ""} className={inputCls} /></Field>
    </div>
  );
  return (
    <div className="space-y-4">
      <PageTitle title="حسابات الدفع" subtitle="تظهر للراكب حسابات شركتك فقط عند الدفع" />
      <Flash sp={sp} />
      <Card>
        <h2 className="mb-3 text-sm font-bold">إضافة حساب جديد</h2>
        <form action={saveAccountAction} className="space-y-3">
          {fields()}
          <button className={btnCls()}>إضافة الحساب</button>
        </form>
      </Card>
      {rows.length === 0 ? (
        <Empty text="لم تضف أي حساب دفع" icon="💳" />
      ) : (
        <div className="grid gap-3 md:grid-cols-2">
          {rows.map((a) => (
            <Card key={a.id}>
              <div className="flex items-start justify-between">
                <div>
                  <div className="font-bold">{a.paymentType}</div>
                  <div className="text-sm text-slate-600">{a.accountName}</div>
                  <div className="font-mono text-sm" dir="ltr">{a.accountNumber}</div>
                  {a.bankName && <div className="text-xs text-slate-400">{a.bankName}</div>}
                </div>
                <StatusBadge map={accountStatus} value={a.status} />
              </div>
              <div className="mt-3 flex gap-3">
                <form action={toggleAccountAction}>
                  <input type="hidden" name="id" value={a.id} />
                  <button className="cursor-pointer text-xs font-semibold text-primary">{a.status === "active" ? "تعطيل" : "تفعيل"}</button>
                </form>
                <form action={deleteAccountAction}>
                  <input type="hidden" name="id" value={a.id} />
                  <ConfirmButton message="حذف هذا الحساب؟" className="cursor-pointer text-xs font-semibold text-red-600">حذف</ConfirmButton>
                </form>
              </div>
              <details className="mt-3">
                <summary className="cursor-pointer text-xs font-semibold text-slate-600">تعديل البيانات</summary>
                <form action={saveAccountAction} className="mt-3 space-y-3">
                  <input type="hidden" name="id" value={a.id} />
                  {fields(a)}
                  <button className={btnCls("outline", true)}>حفظ</button>
                </form>
              </details>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
