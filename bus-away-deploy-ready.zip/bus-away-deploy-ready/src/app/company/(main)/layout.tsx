import type { ReactNode } from "react";
import { NavLinks, type NavItem } from "@/components/client";
import { ThemeToggle } from "@/components/theme-toggle";
import { Logo } from "@/components/ui";
import { can, isManager, requireCompany } from "@/lib/auth";
import { roleLabel } from "@/lib/format";
import { getSettings } from "@/lib/settings";
import { companyLogoutAction } from "@/app/company/actions";

export default async function CompanyMain({ children }: { children: ReactNode }) {
  const { user, company } = await requireCompany();
  const s = await getSettings();
  const m = isManager(user);
  const chat = m || s.employee_chat_allowed === "true";
  const items: NavItem[] = [
    { href: "/company", label: "لوحة التحكم", icon: "📊", exact: true },
    ...(can(user, "bookings") || can(user, "payments") ? [{ href: "/company/bookings", label: "الحجوزات", icon: "🎫" }] : []),
    ...(can(user, "trips") ? [{ href: "/company/trips", label: "الرحلات", icon: "🚌" }] : []),
    ...(can(user, "scan") ? [{ href: "/company/scan", label: "فحص التذاكر", icon: "📷" }] : []),
    ...(m
      ? [
          { href: "/company/accounts", label: "حسابات الدفع", icon: "💳" },
          { href: "/company/staff", label: "الموظفون", icon: "👥" },
          { href: "/company/reports", label: "التقارير", icon: "📈" },
          { href: "/company/expenses", label: "المصروفات", icon: "🧾" },
          { href: "/company/requests", label: "طلبات الإدارة", icon: "📨" },
        ]
      : []),
    ...(chat ? [{ href: "/company/chat", label: "الدردشة", icon: "💬" }] : []),
    ...(m
      ? [
          { href: "/company/profile", label: "بيانات الشركة", icon: "🏢" },
          { href: "/company/audit", label: "سجل العمليات", icon: "🛡️" },
        ]
      : []),
  ];
  return (
    <div className="min-h-screen">
      <header className="no-print sticky top-0 z-20 border-b border-slate-200 bg-white">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            <Logo src={company.logo} name={company.name} size={38} />
            <div>
              <div className="text-sm font-extrabold text-slate-900">{company.name}</div>
              <div className="text-[11px] text-slate-500">{s.app_name} • إدارة الشركات</div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <ThemeToggle returnTo="/company" />
            <div className="hidden text-left text-xs sm:block">
              <div className="font-semibold text-slate-800">{user.name}</div>
              <div className="text-slate-500">{roleLabel[user.role]}</div>
            </div>
            <form action={companyLogoutAction}>
              <button className="rounded-xl bg-slate-100 px-3 py-2 text-xs font-semibold text-slate-700">خروج</button>
            </form>
          </div>
        </div>
        <div className="px-4 pb-2 lg:hidden">
          <NavLinks items={items} variant="scroll" />
        </div>
      </header>
      <div className="mx-auto flex max-w-7xl gap-6 p-4">
        <aside className="no-print hidden w-56 shrink-0 lg:block">
          <div className="sticky top-20">
            <NavLinks items={items} variant="side" />
          </div>
        </aside>
        <main className="min-w-0 flex-1">
          {company.status === "pending" && (
            <div className="mb-4 rounded-xl bg-amber-50 p-3 text-sm text-amber-800">
              ⏳ شركتك قيد المراجعة من مدير النظام، لن تظهر رحلاتك للركاب حتى يتم تفعيلها.
            </div>
          )}
          {children}
        </main>
      </div>
    </div>
  );
}
