import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { go } from "@/lib/nav";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { passengers, payments, tickets } from "@/db/schema";
import { Card, Flash, PageTitle, Row, StatusBadge, btnCls, inputCls } from "@/components/ui";
import { can, requireCompany } from "@/lib/auth";
import { loadBooking, seatStates } from "@/lib/booking";
import { bookingStatus, fmtDate, fmtDateTime, fmtTime, money, paymentStatus, ticketStatus } from "@/lib/format";
import { getSettings } from "@/lib/settings";
import {
  cancelBookingByCompanyAction,
  changeSeatAction,
  markNoShowAction,
  reviewPaymentAction,
  sendNotificationAction,
} from "@/app/company/actions";

export const metadata = { title: "تفاصيل الحجز" };

export default async function CompanyBookingDetail({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const { id } = await params;
  const sp = await searchParams;
  const { user, company } = await requireCompany();
  if (!can(user, "bookings") && !can(user, "payments")) go("/company", { error: "لا تملك صلاحية عرض الحجوزات" });
  const s = await getSettings();
  const tb = await loadBooking(Number(id));
  // عزل الشركات: لا يمكن عرض حجز شركة أخرى
  if (!tb || tb.booking.companyId !== company.id) notFound();
  const { booking: b, trip: t } = tb;
  const [pax] = await db.select().from(passengers).where(eq(passengers.id, b.passengerId));
  const [pay] = await db.select().from(payments).where(eq(payments.bookingId, b.id)).orderBy(desc(payments.id));
  const [tk] = await db.select().from(tickets).where(eq(tickets.bookingId, b.id));
  const states = await seatStates(t.id);
  const free = states.filter((x) => x.state === "open").map((x) => x.n);
  const manage = can(user, "payments");
  const active = ["pending", "awaiting_payment", "confirmed"].includes(b.status);
  return (
    <div className="space-y-4">
      <Link href="/company/bookings" className="text-sm text-primary">← الحجوزات</Link>
      <Flash sp={sp} />
      <PageTitle
        title={`الحجز ${b.bookingNumber}`}
        subtitle={`أُنشئ في ${fmtDateTime(b.createdAt)}${b.source === "admin" ? " • حجز إداري" : ""}`}
        actions={
          <>
            <StatusBadge map={bookingStatus} value={b.status} />
            {tk && <Link href={`/company/bookings/${b.id}/ticket`} className={btnCls("outline", true)}>🎫 عرض / طباعة التذكرة</Link>}
          </>
        }
      />
      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <h3 className="mb-2 text-sm font-bold">الراكب</h3>
          <Row k="الاسم" v={pax.name} />
          <Row k="رقم الراكب" v={pax.passengerNumber} />
          <Row k="الهاتف" v={<span dir="ltr">{pax.phone}</span>} />
          <Row k="الولاية / المدينة" v={`${pax.state ?? "-"} / ${pax.city ?? "-"}`} />
        </Card>
        <Card>
          <h3 className="mb-2 text-sm font-bold">الرحلة</h3>
          <Row k="خط السير" v={`${t.fromCity} ← ${t.toCity}`} />
          <Row k="الموعد" v={`${fmtDate(t.departureDate)} - ${fmtTime(t.departureTime)}`} />
          <Row k="المقعد" v={<b className="text-primary">{b.seatNumber}</b>} />
          <Row k="السعر" v={money(b.price, s.currency)} />
          {tk && <Row k="التذكرة" v={<span>{tk.ticketNumber} <StatusBadge map={ticketStatus} value={tk.status} /></span>} />}
        </Card>
      </div>
      <Card>
        <h3 className="mb-2 text-sm font-bold">الدفع</h3>
        {!pay ? (
          <p className="text-sm text-slate-500">لم يرسل الراكب بيانات الدفع بعد.</p>
        ) : (
          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <Row k="الطريقة" v={pay.paymentMethod} />
              <Row k="رقم العملية" v={pay.transactionNumber ?? "-"} />
              <Row k="تاريخ ووقت العملية" v={`${pay.transactionDate ?? "-"} ${pay.transactionTime ?? ""}`} />
              <Row k="المبلغ" v={money(pay.amount, s.currency)} />
              <Row k="الحالة" v={<StatusBadge map={paymentStatus} value={pay.status} />} />
              {pay.note && <Row k="ملاحظة" v={pay.note} />}
              {pay.reviewedAt && <Row k="تمت المراجعة" v={fmtDateTime(pay.reviewedAt)} />}
            </div>
            <div>
              {pay.receiptImage ? (
                <a href={pay.receiptImage} target="_blank" rel="noreferrer">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={pay.receiptImage} alt="إشعار التحويل" className="max-h-72 w-full rounded-xl border object-contain" />
                </a>
              ) : (
                <p className="text-sm text-slate-400">لا توجد صورة إشعار</p>
              )}
            </div>
          </div>
        )}
        {manage && pay && ["under_review", "needs_edit"].includes(pay.status) && b.status === "awaiting_payment" && (
          <form action={reviewPaymentAction} className="mt-4 space-y-3 border-t border-slate-100 pt-4">
            <input type="hidden" name="bookingId" value={b.id} />
            <input type="hidden" name="paymentId" value={pay.id} />
            <input name="note" placeholder="ملاحظة للراكب (سبب الرفض أو التعديل المطلوب)" className={inputCls} />
            <div className="flex flex-wrap gap-2">
              <button name="action" value="accept" className={btnCls("success")}>✔ قبول الدفع وإصدار التذكرة</button>
              <button name="action" value="reject" className={btnCls("danger")}>✖ رفض الدفع</button>
              <button name="action" value="needs_edit" className={btnCls("warn")}>✏️ طلب تعديل</button>
            </div>
          </form>
        )}
      </Card>
      {manage && active && (
        <div className="grid gap-4 lg:grid-cols-2">
          <Card>
            <h3 className="mb-2 text-sm font-bold">تغيير المقعد</h3>
            <form action={changeSeatAction} className="flex gap-2">
              <input type="hidden" name="bookingId" value={b.id} />
              <select name="seat" className={inputCls} required>
                {free.map((n) => <option key={n} value={n}>مقعد {n}</option>)}
              </select>
              <button className={btnCls("outline")}>تغيير</button>
            </form>
          </Card>
          <Card>
            <h3 className="mb-2 text-sm font-bold">إلغاء الحجز</h3>
            <form action={cancelBookingByCompanyAction} className="flex gap-2">
              <input type="hidden" name="bookingId" value={b.id} />
              <input name="reason" placeholder="سبب الإلغاء (اختياري)" className={inputCls} />
              <button className={btnCls("danger")}>إلغاء</button>
            </form>
          </Card>
        </div>
      )}
      {can(user, "bookings") && (
        <Card>
          <h3 className="mb-2 text-sm font-bold">إرسال إشعار للراكب</h3>
          <form action={sendNotificationAction} className="flex gap-2">
            <input type="hidden" name="bookingId" value={b.id} />
            <input name="message" required placeholder="نص الرسالة" className={inputCls} />
            <button className={btnCls()}>إرسال</button>
          </form>
          {b.status === "confirmed" && can(user, "scan") && (
            <form action={markNoShowAction} className="mt-3">
              <input type="hidden" name="bookingId" value={b.id} />
              <button className={btnCls("outline", true)}>تسجيل «لم يحضر الراكب»</button>
            </form>
          )}
        </Card>
      )}
    </div>
  );
}
