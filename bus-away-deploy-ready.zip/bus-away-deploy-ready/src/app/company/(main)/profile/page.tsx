import { redirect } from "next/navigation";
import { go } from "@/lib/nav";
import { FileUpload } from "@/components/client";
import { Card, Field, Flash, PageTitle, StatusBadge, btnCls, inputCls } from "@/components/ui";
import { isManager, requireCompany } from "@/lib/auth";
import { companyStatus } from "@/lib/format";
import { updateCompanyAction, updateCompanyLogoAction } from "@/app/company/actions";

export const metadata = { title: "بيانات الشركة" };

export default async function CompanyProfile({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  const { user, company: c } = await requireCompany();
  if (!isManager(user)) go("/company", { error: "هذه الصفحة لمدير المكتب فقط" });
  return (
    <div className="max-w-2xl space-y-4">
      <PageTitle title="بيانات الشركة" actions={<StatusBadge map={companyStatus} value={c.status} />} />
      <Flash sp={sp} />
      <Card>
        <form action={updateCompanyAction} className="space-y-3">
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="اسم الشركة" hint="يعدله مدير النظام فقط"><input value={c.name} disabled className={inputCls} readOnly /></Field>
            <Field label="رقم الترخيص" hint="يعدله مدير النظام فقط"><input value={c.licenseNumber ?? ""} disabled className={inputCls} readOnly /></Field>
            <Field label="الهاتف"><input name="phone" defaultValue={c.phone ?? ""} className={inputCls} /></Field>
            <Field label="البريد الإلكتروني"><input name="email" type="email" defaultValue={c.email ?? ""} className={inputCls} /></Field>
          </div>
          <Field label="العنوان"><input name="address" defaultValue={c.address ?? ""} className={inputCls} /></Field>
          <Field label="الولايات / الخطوط التي تعمل بها"><input name="routes" defaultValue={c.routes ?? ""} className={inputCls} /></Field>
          <button className={btnCls()}>حفظ</button>
        </form>
      </Card>
      <Card>
        <h2 className="mb-1 text-sm font-bold">شعار الشركة</h2>
        <p className="mb-3 text-xs text-slate-500">اختر صورة من المعرض؛ تُقص تلقائياً إلى مربع ويظهر الشعار للركاب في الرحلات والتذاكر. تغييره متاح لمدير المكتب فقط.</p>
        <form action={updateCompanyLogoAction} className="space-y-3">
          <FileUpload name="logo" label="الصورة" initial={c.logo} square={512} removable hint="يفضّل صورة مربعة واضحة بحجم 512×512" />
          <button className={btnCls()}>حفظ الشعار</button>
        </form>
      </Card>
    </div>
  );
}
