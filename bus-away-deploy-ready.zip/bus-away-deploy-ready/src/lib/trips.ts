import { and, asc, eq, gte, inArray, or } from "drizzle-orm";
import { db } from "@/db";
import { cities, companies, states, trips } from "@/db/schema";
import { depAt, todayStr } from "@/lib/format";

export async function searchTrips(f: { from?: string; to?: string; date?: string; limit?: number }) {
  const conds = [
    eq(companies.status, "active"),
    inArray(trips.status, ["open", "full"]),
    gte(trips.departureDate, todayStr()),
  ];
  if (f.date) conds.push(eq(trips.departureDate, f.date));
  if (f.from) conds.push(or(eq(trips.fromCity, f.from), eq(trips.fromState, f.from))!);
  if (f.to) conds.push(or(eq(trips.toCity, f.to), eq(trips.toState, f.to))!);
  const rows = await db
    .select({ trip: trips, company: companies })
    .from(trips)
    .innerJoin(companies, eq(companies.id, trips.companyId))
    .where(and(...conds))
    .orderBy(asc(trips.departureDate), asc(trips.departureTime))
    .limit(200);
  const now = new Date();
  return rows.filter((r) => depAt(r.trip.departureDate, r.trip.departureTime) > now).slice(0, f.limit ?? 50);
}

export type Geo = { state: string; cities: string[] }[];

export async function getGeo(): Promise<Geo> {
  const ss = await db.select().from(states).orderBy(asc(states.name));
  const cs = await db.select().from(cities).orderBy(asc(cities.name));
  return ss.map((s) => ({ state: s.name, cities: cs.filter((c) => c.stateId === s.id).map((c) => c.name) }));
}
