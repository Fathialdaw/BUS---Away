import { redirect } from "next/navigation";

export function go(path: string, m?: { ok?: string; error?: string }): never {
  const u = new URL(path, "http://local");
  if (m?.ok) u.searchParams.set("ok", m.ok);
  if (m?.error) u.searchParams.set("error", m.error);
  redirect(u.pathname + u.search);
}
