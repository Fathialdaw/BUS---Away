import { and, count, desc, eq, inArray, lt, not, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  auditLogs,
  bookings,
  companies,
  companyAccounts,
  notifications,
  passengers,
  payments,
  tickets,
  trips,
  tripSeats,
} from "@/db/schema";
import { TEMPLATE_META, getSettings, renderTpl } from "@/lib/settings";
import { depAt, digits, fmtDate, fmtTime } from "@/lib/format";

export const ACTIVE = ["pending", "awaiting_payment", "confirmed", "completed", "no_show"];

export type Actor = {
  userId?: number | null;
  name: string;
  type: "admin" | "manager" | "employee" | "passenger" | "system";
  companyId?: number | null;
};

export async function audit(
  actor: Actor,
  action: string,
  entityType: string,
  entityId: string | number | null,
  oldData?: unknown,
  newData?: unknown,
) {
  try {
    await db.insert(auditLogs).values({
      userId: actor.userId ?? null,
      actorName: actor.name,
      actorType: actor.type,
      companyId: actor.companyId ?? null,
      action,
      entityType,
      entityId: entityId == null ? null : String(entityId),
      oldData: oldData ?? null,
      newData: newData ?? null,
    });
  } catch {
    /* لا نفشل العملية بسبب السجل */
  }
}

export type SeatState = "open" | "booked" | "locked";

export async function seatStates(tripId: number): Promise<{ n: number; state: SeatState }[]> {
  const [t] = await db.select().from(trips).where(eq(trips.id, tripId));
  if (!t) return [];
  const taken = await takenSeats(tripId);
  const rows = await db.select().from(tripSeats).where(eq(tripSeats.tripId, tripId));
  const locked = new Set(rows.filter((r) => r.status === "blocked").map((r) => r.seatNumber));
  const out: { n: number; state: SeatState }[] = [];
  for (let n = 1; n <= t.totalSeats; n++) {
    out.push({ n, state: taken.includes(n) ? "booked" : locked.has(n) ? "locked" : "open" });
  }
  return out;
}

export async function syncSeats(tripId: number) {
  const [{ c }] = await db
    .select({ c: count() })
    .from(bookings)
    .where(and(eq(bookings.tripId, tripId), inArray(bookings.status, ACTIVE)));
  // المقاعد المحظورة من الشركة (مع استبعاد ما هو محجوز فعلاً حتى لا يُحسب مرتين)
  const [{ l }] = await db
    .select({ l: count() })
    .from(tripSeats)
    .where(
      and(
        eq(tripSeats.tripId, tripId),
        eq(tripSeats.status, "blocked"),
        not(
          sql`${tripSeats.seatNumber} in (select ${bookings.seatNumber} from ${bookings} where ${bookings.tripId} = ${tripId} and ${bookings.status} in ('pending','awaiting_payment','confirmed','completed','no_show'))`,
        ),
      ),
    );
  const [t] = await db.select().from(trips).where(eq(trips.id, tripId));
  if (!t) return;
  const avail = Math.max(0, t.totalSeats - c - l);
  let status = t.status;
  if (status === "open" && avail === 0) status = "full";
  else if (status === "full" && avail > 0) status = "open";
  await db.update(trips).set({ availableSeats: avail, status }).where(eq(trips.id, tripId));
}

export async function releaseExpired() {
  const rows = await db
    .update(bookings)
    .set({ status: "cancelled" })
    .where(and(eq(bookings.status, "pending"), lt(bookings.expiresAt, new Date())))
    .returning({ tripId: bookings.tripId });
  for (const id of new Set(rows.map((r) => r.tripId))) await syncSeats(id);
}

export async function takenSeats(tripId: number): Promise<number[]> {
  const rows = await db
    .select({ s: bookings.seatNumber })
    .from(bookings)
    .where(and(eq(bookings.tripId, tripId), inArray(bookings.status, ACTIVE)));
  return rows.map((r) => r.s);
}

export async function notifyPassenger(
  passengerId: number,
  type: string,
  title: string,
  message: string,
  refKey?: string,
) {
  await db
    .insert(notifications)
    .values({ passengerId, type, title, message, refKey: refKey ?? null })
    .onConflictDoNothing();
}

type TripBooking = {
  booking: typeof bookings.$inferSelect;
  trip: typeof trips.$inferSelect;
  company: typeof companies.$inferSelect;
};

export async function loadBooking(id: number): Promise<TripBooking | null> {
  const [r] = await db
    .select({ booking: bookings, trip: trips, company: companies })
    .from(bookings)
    .innerJoin(trips, eq(trips.id, bookings.tripId))
    .innerJoin(companies, eq(companies.id, bookings.companyId))
    .where(eq(bookings.id, id));
  return r ?? null;
}

export async function tplNotify(
  key: (typeof TEMPLATE_META)[number]["key"],
  tb: TripBooking,
  extra: Record<string, string> = {},
  refKey?: string,
) {
  const s = await getSettings();
  const meta = TEMPLATE_META.find((t) => t.key === key)!;
  const msg = renderTpl(s[key] ?? meta.def, {
    booking: tb.booking.bookingNumber,
    route: `${tb.trip.fromCity} ← ${tb.trip.toCity}`.replace("←", "إلى"),
    date: fmtDate(tb.trip.departureDate),
    time: fmtTime(tb.trip.departureTime),
    seat: tb.booking.seatNumber,
    company: tb.company.name,
    meeting: tb.trip.meetingPoint ?? "نقطة التجمع",
    note: "",
    ...extra,
  });
  await notifyPassenger(tb.booking.passengerId, meta.type, meta.title, msg, refKey);
}

export async function createBooking(opts: {
  passengerId: number;
  tripId: number;
  seat: number;
}): Promise<{ id?: number; error?: string }> {
  await releaseExpired();
  const [r] = await db
    .select({ trip: trips, company: companies })
    .from(trips)
    .innerJoin(companies, eq(companies.id, trips.companyId))
    .where(eq(trips.id, opts.tripId));
  if (!r) return { error: "الرحلة غير موجودة" };
  const { trip, company } = r;
  if (company.status !== "active") return { error: "الشركة غير متاحة حالياً" };
  if (trip.status !== "open") return { error: "هذه الرحلة غير متاحة للحجز" };
  if (depAt(trip.departureDate, trip.departureTime) < new Date()) return { error: "انتهى موعد الرحلة" };
  if (!Number.isInteger(opts.seat) || opts.seat < 1 || opts.seat > trip.totalSeats)
    return { error: "رقم المقعد غير صحيح" };
  const [sr] = await db
    .select()
    .from(tripSeats)
    .where(and(eq(tripSeats.tripId, trip.id), eq(tripSeats.seatNumber, opts.seat)));
  if (sr?.status !== "open") return { error: "هذا المقعد غير متاح، اختر مقعداً آخر" };
  const s = await getSettings();
  const expires = new Date(Date.now() + Number(s.hold_minutes || 30) * 60000);
  try {
    const [b] = await db
      .insert(bookings)
      .values({
        bookingNumber: `BK-${new Date().toISOString().slice(0, 10).replace(/-/g, "")}-${digits(5)}`,
        passengerId: opts.passengerId,
        tripId: trip.id,
        companyId: trip.companyId,
        seatNumber: opts.seat,
        price: trip.price,
        status: "pending",
        expiresAt: expires,
      })
      .returning();
    await syncSeats(trip.id);
    return { id: b.id };
  } catch {
    return { error: "هذا المقعد محجوز بالفعل، اختر مقعداً آخر" };
  }
}

export async function submitPayment(opts: {
  bookingId: number;
  passengerId: number;
  accountId: number;
  transactionNumber: string;
  transactionDate: string;
  transactionTime: string;
  receiptImage: string;
}): Promise<{ error?: string }> {
  const tb = await loadBooking(opts.bookingId);
  if (!tb || tb.booking.passengerId !== opts.passengerId) return { error: "الحجز غير موجود" };
  const [existing] = await db.select().from(payments).where(eq(payments.bookingId, opts.bookingId));
  const editable =
    tb.booking.status === "pending" ||
    (tb.booking.status === "awaiting_payment" && existing?.status === "needs_edit");
  if (!editable) return { error: "لا يمكن إرسال بيانات الدفع لهذا الحجز" };
  if (tb.booking.status === "pending" && tb.booking.expiresAt && tb.booking.expiresAt < new Date())
    return { error: "انتهت مهلة الحجز" };
  // يجب أن يكون الحساب تابعاً لشركة الرحلة فقط
  const [acc] = await db
    .select()
    .from(companyAccounts)
    .where(
      and(
        eq(companyAccounts.id, opts.accountId),
        eq(companyAccounts.companyId, tb.booking.companyId),
        eq(companyAccounts.status, "active"),
      ),
    );
  if (!acc) return { error: "حساب الدفع المختار غير صالح لهذه الشركة" };
  if (!opts.transactionNumber) return { error: "أدخل رقم العملية" };
  if (!opts.receiptImage) return { error: "ارفع صورة إشعار التحويل" };
  const data = {
    companyAccountId: acc.id,
    paymentMethod: acc.paymentType,
    transactionNumber: opts.transactionNumber,
    transactionDate: opts.transactionDate,
    transactionTime: opts.transactionTime,
    amount: tb.booking.price,
    receiptImage: opts.receiptImage,
    status: "under_review",
    note: null,
  };
  if (existing) await db.update(payments).set({ ...data, reviewedAt: null, reviewedBy: null }).where(eq(payments.id, existing.id));
  else await db.insert(payments).values({ bookingId: tb.booking.id, ...data });
  await db.update(bookings).set({ status: "awaiting_payment", expiresAt: null }).where(eq(bookings.id, tb.booking.id));
  await audit({ name: "راكب", type: "passenger", userId: null, companyId: tb.booking.companyId }, "submit_payment", "booking", tb.booking.id, null, { method: acc.paymentType, tx: opts.transactionNumber });
  return {};
}

export async function issueTicket(bookingId: number) {
  const [ex] = await db.select().from(tickets).where(eq(tickets.bookingId, bookingId));
  if (ex) {
    await db.update(tickets).set({ status: "confirmed" }).where(eq(tickets.id, ex.id));
    return ex;
  }
  const num = `TK-${digits(8)}`;
  const [t] = await db
    .insert(tickets)
    .values({ bookingId, ticketNumber: num, barcode: num.replace("TK-", ""), qrCode: num, status: "confirmed" })
    .returning();
  return t;
}

export async function reviewPayment(
  paymentId: number,
  action: "accept" | "reject" | "needs_edit",
  actor: Actor,
  note = "",
  scopeCompanyId?: number,
): Promise<{ error?: string }> {
  const [p] = await db.select().from(payments).where(eq(payments.id, paymentId));
  if (!p) return { error: "عملية الدفع غير موجودة" };
  const tb = await loadBooking(p.bookingId);
  if (!tb) return { error: "الحجز غير موجود" };
  if (scopeCompanyId && tb.booking.companyId !== scopeCompanyId) return { error: "غير مصرح لك بهذه العملية" };
  const old = { payment: p.status, booking: tb.booking.status };
  const reviewer = { reviewedBy: actor.userId ?? null, reviewedAt: new Date() };
  if (action === "accept") {
    await db.update(payments).set({ status: "accepted", note: note || null, ...reviewer }).where(eq(payments.id, p.id));
    await db.update(bookings).set({ status: "confirmed", expiresAt: null }).where(eq(bookings.id, tb.booking.id));
    await issueTicket(tb.booking.id);
    await tplNotify("tpl_confirmed", tb, {}, `confirmed:${tb.booking.id}`);
  } else if (action === "reject") {
    await db.update(payments).set({ status: "rejected", note: note || null, ...reviewer }).where(eq(payments.id, p.id));
    await db.update(bookings).set({ status: "rejected" }).where(eq(bookings.id, tb.booking.id));
    await syncSeats(tb.trip.id);
    await tplNotify("tpl_payment_rejected", tb, { note: note ? `السبب: ${note}` : "" });
  } else {
    await db.update(payments).set({ status: "needs_edit", note: note || null, ...reviewer }).where(eq(payments.id, p.id));
    await notifyPassenger(
      tb.booking.passengerId,
      "payment_edit",
      "بيانات الدفع تحتاج إلى تعديل",
      `يرجى تعديل بيانات الدفع للحجز ${tb.booking.bookingNumber}. ${note}`,
    );
  }
  await audit(actor, `payment_${action}`, "payment", p.id, old, { note });
  return {};
}

export async function cancelBooking(bookingId: number, actor: Actor, reason = "", scopeCompanyId?: number): Promise<{ error?: string }> {
  const tb = await loadBooking(bookingId);
  if (!tb) return { error: "الحجز غير موجود" };
  if (scopeCompanyId && tb.booking.companyId !== scopeCompanyId) return { error: "غير مصرح لك بهذه العملية" };
  if (["cancelled", "rejected", "completed"].includes(tb.booking.status)) return { error: "لا يمكن إلغاء هذا الحجز" };
  await db.update(bookings).set({ status: "cancelled" }).where(eq(bookings.id, bookingId));
  await db.update(tickets).set({ status: "cancelled" }).where(eq(tickets.bookingId, bookingId));
  await db.update(payments).set({ status: "refunded" }).where(and(eq(payments.bookingId, bookingId), eq(payments.status, "accepted")));
  await syncSeats(tb.trip.id);
  if (actor.type !== "passenger")
    await notifyPassenger(
      tb.booking.passengerId,
      "booking_cancelled",
      "تم إلغاء الحجز",
      `تم إلغاء حجزك رقم ${tb.booking.bookingNumber}. ${reason}`,
    );
  await audit(actor, "cancel_booking", "booking", bookingId, { status: tb.booking.status }, { status: "cancelled", reason });
  return {};
}

export async function changeSeat(bookingId: number, seat: number, actor: Actor, scopeCompanyId?: number): Promise<{ error?: string }> {
  const tb = await loadBooking(bookingId);
  if (!tb) return { error: "الحجز غير موجود" };
  if (scopeCompanyId && tb.booking.companyId !== scopeCompanyId) return { error: "غير مصرح لك بهذه العملية" };
  if (!ACTIVE.includes(tb.booking.status)) return { error: "لا يمكن تغيير مقعد هذا الحجز" };
  if (!Number.isInteger(seat) || seat < 1 || seat > tb.trip.totalSeats) return { error: "رقم المقعد غير صحيح" };
  const [sr] = await db
    .select()
    .from(tripSeats)
    .where(and(eq(tripSeats.tripId, tb.trip.id), eq(tripSeats.seatNumber, seat)));
  if (sr?.status !== "open") return { error: "المقعد المطلوب محجوز من الشركة" };
  try {
    await db.update(bookings).set({ seatNumber: seat }).where(eq(bookings.id, bookingId));
  } catch {
    return { error: "المقعد محجوز بالفعل" };
  }
  await tplNotify("tpl_seat_changed", { ...tb, booking: { ...tb.booking, seatNumber: seat } });
  await audit(actor, "change_seat", "booking", bookingId, { seat: tb.booking.seatNumber }, { seat });
  return {};
}

export async function cancelTrip(tripId: number, actor: Actor): Promise<void> {
  const [trip] = await db.select().from(trips).where(eq(trips.id, tripId));
  if (!trip) return;
  const rows = await db.select({ id: bookings.id }).from(bookings).where(and(eq(bookings.tripId, tripId), inArray(bookings.status, ACTIVE)));
  await db.update(trips).set({ status: "cancelled" }).where(eq(trips.id, tripId));
  for (const r of rows) {
    const tb = await loadBooking(r.id);
    if (!tb) continue;
    await db.update(bookings).set({ status: "cancelled" }).where(eq(bookings.id, r.id));
    await db.update(tickets).set({ status: "cancelled" }).where(eq(tickets.bookingId, r.id));
    await db.update(payments).set({ status: "refunded" }).where(and(eq(payments.bookingId, r.id), eq(payments.status, "accepted")));
    await tplNotify("tpl_trip_cancelled", tb);
  }
  await db.update(trips).set({ availableSeats: trip.totalSeats }).where(eq(trips.id, tripId));
  await audit(actor, "cancel_trip", "trip", tripId, { status: trip.status }, { status: "cancelled", affected: rows.length });
}

export async function notifyTripTimeChanged(tripId: number) {
  const rows = await db.select({ id: bookings.id }).from(bookings).where(and(eq(bookings.tripId, tripId), inArray(bookings.status, ["confirmed", "awaiting_payment", "pending"])));
  for (const r of rows) {
    const tb = await loadBooking(r.id);
    if (tb) await tplNotify("tpl_time_changed", tb);
  }
}

export async function checkInTicket(code: string, actor: Actor, scopeCompanyId: number) {
  const clean = code.trim();
  const [r] = await db
    .select({ ticket: tickets, booking: bookings })
    .from(tickets)
    .innerJoin(bookings, eq(bookings.id, tickets.bookingId))
    .where(sql`${tickets.ticketNumber} = ${clean} or ${tickets.barcode} = ${clean}`);
  if (!r) return { error: "التذكرة غير موجودة" };
  if (r.booking.companyId !== scopeCompanyId) return { error: "هذه التذكرة تابعة لشركة أخرى" };
  if (r.ticket.status === "used") return { error: "هذه التذكرة مستخدمة مسبقاً" };
  if (r.ticket.status !== "confirmed" && r.ticket.status !== "issued") return { error: "التذكرة غير صالحة للصعود" };
  await db.update(tickets).set({ status: "used", checkedAt: new Date(), checkedBy: actor.userId ?? null }).where(eq(tickets.id, r.ticket.id));
  await db.update(bookings).set({ status: "completed" }).where(eq(bookings.id, r.booking.id));
  await audit(actor, "check_in", "ticket", r.ticket.id, { status: r.ticket.status }, { status: "used" });
  return { ok: "تم تسجيل صعود الراكب بنجاح" };
}

export async function generateReminders(passengerId: number) {
  const rows = await db
    .select({ booking: bookings, trip: trips, company: companies })
    .from(bookings)
    .innerJoin(trips, eq(trips.id, bookings.tripId))
    .innerJoin(companies, eq(companies.id, bookings.companyId))
    .where(and(eq(bookings.passengerId, passengerId), eq(bookings.status, "confirmed")));
  for (const tb of rows) {
    const hours = (depAt(tb.trip.departureDate, tb.trip.departureTime).getTime() - Date.now()) / 36e5;
    if (hours <= 0 || hours > 48) continue;
    const k = hours <= 1 ? "1h" : hours <= 12 ? "12h" : "2d";
    const key = (`tpl_reminder_${k}`) as "tpl_reminder_1h" | "tpl_reminder_12h" | "tpl_reminder_2d";
    await tplNotify(key, tb, {}, `rem:${tb.booking.id}:${k}`);
  }
}

export async function getTicketData(bookingId: number) {
  const [r] = await db
    .select({
      ticket: tickets,
      booking: bookings,
      trip: trips,
      company: companies,
      passenger: passengers,
    })
    .from(tickets)
    .innerJoin(bookings, eq(bookings.id, tickets.bookingId))
    .innerJoin(trips, eq(trips.id, bookings.tripId))
    .innerJoin(companies, eq(companies.id, bookings.companyId))
    .innerJoin(passengers, eq(passengers.id, bookings.passengerId))
    .where(eq(bookings.id, bookingId));
  if (!r) return null;
  const [pay] = await db.select().from(payments).where(eq(payments.bookingId, bookingId)).orderBy(desc(payments.id));
  return { ...r, payment: pay ?? null };
}
