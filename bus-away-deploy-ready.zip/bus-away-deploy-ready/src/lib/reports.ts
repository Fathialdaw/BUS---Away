import { sql } from "drizzle-orm";
import { db } from "@/db";

type Row = Record<string, unknown>;

async function q(query: ReturnType<typeof sql>): Promise<Row[]> {
  const r = await db.execute(query);
  return r.rows as Row[];
}

export type Point = { label: string; value: number };

export type Report = {
  seats: { sold: number; available: number };
  occupancy: Point[];
  daily: Point[];
  monthly: Point[];
  revenue: Point[];
  expenses: Point[];
  topTrips: Point[];
  companies: { name: string; bookings: number; revenue: number; trips: number }[];
  tripsDone: { done: number; cancelled: number; upcoming: number };
  byState: Point[];
  methods: Point[];
};

const pts = (rows: Row[]): Point[] => rows.map((r) => ({ label: String(r.label), value: Number(r.value) }));

export async function getReport(companyId?: number): Promise<Report> {
  const cT = companyId ? sql`and t.company_id = ${companyId}` : sql``;
  const cB = companyId ? sql`and b.company_id = ${companyId}` : sql``;
  const cE = companyId ? sql`where company_id = ${companyId}` : sql``;

  const seatsR = await q(sql`select coalesce(sum(t.total_seats),0) as total, coalesce(sum(t.available_seats),0) as avail from trips t where t.status not in ('cancelled','ended') ${cT}`);
  const total = Number(seatsR[0]?.total ?? 0);
  const avail = Number(seatsR[0]?.avail ?? 0);

  const occ = await q(sql`select (t.from_city || ' ← ' || t.to_city || ' ' || to_char(t.departure_date,'MM/DD')) as label,
      round(100.0*(t.total_seats - t.available_seats)/nullif(t.total_seats,0)) as value
    from trips t where t.status not in ('cancelled') ${cT} order by t.departure_date desc, t.id desc limit 8`);

  const daily = await q(sql`select to_char(d,'MM/DD') as label, coalesce(c,0) as value from generate_series((current_date - interval '13 days')::date, current_date, '1 day') d
    left join (select b.created_at::date as day, count(*) c from bookings b where b.status not in ('rejected','cancelled') ${cB} group by 1) x on x.day = d::date order by d`);

  const monthly = await q(sql`select to_char(m,'YYYY/MM') as label, coalesce(c,0) as value from generate_series(date_trunc('month', current_date) - interval '5 months', date_trunc('month', current_date), '1 month') m
    left join (select date_trunc('month', b.created_at) as mm, count(*) c from bookings b where b.status not in ('rejected','cancelled') ${cB} group by 1) x on x.mm = m order by m`);

  const rev = await q(sql`select to_char(m,'YYYY/MM') as label, coalesce(c,0) as value from generate_series(date_trunc('month', current_date) - interval '5 months', date_trunc('month', current_date), '1 month') m
    left join (select date_trunc('month', p.created_at) as mm, sum(p.amount) c from payments p join bookings b on b.id = p.booking_id where p.status = 'accepted' ${cB} group by 1) x on x.mm = m order by m`);

  const exp = await q(sql`select to_char(m,'YYYY/MM') as label, coalesce(c,0) as value from generate_series(date_trunc('month', current_date) - interval '5 months', date_trunc('month', current_date), '1 month') m
    left join (select date_trunc('month', expense_date) as mm, sum(amount) c from expenses ${cE} group by 1) x on x.mm = m order by m`);

  const top = await q(sql`select (t.from_city || ' ← ' || t.to_city) as label, count(b.id) as value from bookings b join trips t on t.id = b.trip_id
    where b.status not in ('rejected','cancelled') ${cT} group by 1 order by value desc limit 6`);

  const comp = await q(sql`select c.name, 
      (select count(*) from bookings b where b.company_id = c.id and b.status not in ('rejected','cancelled')) as bookings,
      (select coalesce(sum(p.amount),0) from payments p join bookings b on b.id = p.booking_id where b.company_id = c.id and p.status = 'accepted') as revenue,
      (select count(*) from trips t where t.company_id = c.id) as trips
    from companies c ${companyId ? sql`where c.id = ${companyId}` : sql``} order by revenue desc`);

  const done = await q(sql`select
      count(*) filter (where t.status in ('ended','started')) as done,
      count(*) filter (where t.status = 'cancelled') as cancelled,
      count(*) filter (where t.status in ('open','full','scheduled','postponed')) as upcoming
    from trips t where true ${cT}`);

  const byState = await q(sql`select coalesce(p.state,'غير محدد') as label, count(distinct p.id) as value from bookings b join passengers p on p.id = b.passenger_id
    where b.status not in ('rejected','cancelled') ${cB} group by 1 order by value desc limit 8`);

  const methods = await q(sql`select p.payment_method as label, count(*) as value from payments p join bookings b on b.id = p.booking_id where true ${cB} group by 1 order by value desc`);

  return {
    seats: { sold: total - avail, available: avail },
    occupancy: pts(occ),
    daily: pts(daily),
    monthly: pts(monthly),
    revenue: pts(rev),
    expenses: pts(exp),
    topTrips: pts(top),
    companies: comp.map((r) => ({ name: String(r.name), bookings: Number(r.bookings), revenue: Number(r.revenue), trips: Number(r.trips) })),
    tripsDone: { done: Number(done[0]?.done ?? 0), cancelled: Number(done[0]?.cancelled ?? 0), upcoming: Number(done[0]?.upcoming ?? 0) },
    byState: pts(byState),
    methods: pts(methods),
  };
}

export async function getStats(companyId?: number) {
  const cT = companyId ? sql`and t.company_id = ${companyId}` : sql``;
  const cB = companyId ? sql`and b.company_id = ${companyId}` : sql``;
  const today = new Intl.DateTimeFormat("en-CA", { timeZone: "Africa/Khartoum" }).format(new Date());
  const a = await q(sql`select
      (select count(*) from trips t where true ${cT}) as trips,
      (select count(*) from trips t where t.departure_date >= ${today}::date and t.status in ('open','full','scheduled','postponed') ${cT}) as upcoming,
      (select count(*) from bookings b where true ${cB}) as bookings,
      (select count(*) from bookings b join tickets k on k.booking_id = b.id where k.status in ('confirmed','used') ${cB}) as tickets,
      (select coalesce(sum(t.available_seats),0) from trips t where t.status in ('open','full') and t.departure_date >= ${today}::date ${cT}) as avail,
      (select coalesce(sum(t.total_seats - t.available_seats),0) from trips t where t.status in ('open','full') and t.departure_date >= ${today}::date ${cT}) as booked,
      (select coalesce(sum(p.amount),0) from payments p join bookings b on b.id = p.booking_id where p.status = 'accepted' ${cB}) as collected,
      (select count(*) from payments p join bookings b on b.id = p.booking_id where p.status = 'under_review' ${cB}) as pending,
      (select count(*) from companies) as companies,
      (select count(*) from passengers) as passengers,
      (select count(*) from users) as users`);
  const r = a[0];
  return {
    trips: Number(r.trips),
    upcoming: Number(r.upcoming),
    bookings: Number(r.bookings),
    tickets: Number(r.tickets),
    avail: Number(r.avail),
    booked: Number(r.booked),
    collected: Number(r.collected),
    pending: Number(r.pending),
    companies: Number(r.companies),
    passengers: Number(r.passengers),
    users: Number(r.users),
  };
}
