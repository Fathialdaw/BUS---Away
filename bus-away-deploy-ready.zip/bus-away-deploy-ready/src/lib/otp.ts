import { and, desc, eq, gt } from "drizzle-orm";
import { db } from "@/db";
import { otps } from "@/db/schema";
import { digits } from "@/lib/format";

export function normPhone(s: string): string {
  return s
    .replace(/[٠-٩]/g, (d) => String("٠١٢٣٤٥٦٧٨٩".indexOf(d)))
    .replace(/[\s\-()]/g, "");
}

export async function createOtp(phone: string, purpose: "activate" | "login" | "reset") {
  const code = digits(6);
  await db.insert(otps).values({
    phone,
    purpose,
    code,
    expiresAt: new Date(Date.now() + 10 * 60000),
  });
  return code;
}

export async function checkOtp(phone: string, purpose: string, code: string): Promise<boolean> {
  const [o] = await db
    .select()
    .from(otps)
    .where(and(eq(otps.phone, phone), eq(otps.purpose, purpose), eq(otps.used, false), gt(otps.expiresAt, new Date())))
    .orderBy(desc(otps.id))
    .limit(1);
  if (!o || o.code !== code) return false;
  await db.update(otps).set({ used: true }).where(eq(otps.id, o.id));
  return true;
}

export async function latestOtp(phone: string, purpose: string): Promise<string | null> {
  const [o] = await db
    .select()
    .from(otps)
    .where(and(eq(otps.phone, phone), eq(otps.purpose, purpose), eq(otps.used, false), gt(otps.expiresAt, new Date())))
    .orderBy(desc(otps.id))
    .limit(1);
  return o?.code ?? null;
}
