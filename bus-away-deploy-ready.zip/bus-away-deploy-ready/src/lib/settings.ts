import { cache } from "react";
import { db } from "@/db";
import { settings } from "@/db/schema";
import { ensureSeed } from "@/lib/seed";

export const TEMPLATE_META = [
  {
    key: "tpl_confirmed",
    type: "booking_confirmed",
    title: "تم تأكيد الحجز",
    def: "تم تأكيد حجزك رقم {booking} على رحلة {route} بتاريخ {date} الساعة {time}، المقعد رقم {seat}.",
  },
  {
    key: "tpl_reminder_2d",
    type: "reminder",
    title: "تبقى يومان على موعد الرحلة",
    def: "تذكير: رحلتك {route} مع {company} بعد يومين، بتاريخ {date} الساعة {time}، المقعد {seat}.",
  },
  {
    key: "tpl_reminder_12h",
    type: "reminder",
    title: "تبقى 12 ساعة على الرحلة",
    def: "تبقى 12 ساعة على رحلتك {route}. نقطة التجمع: {meeting}.",
  },
  {
    key: "tpl_reminder_1h",
    type: "reminder",
    title: "تبقى ساعة على موعد المغادرة",
    def: "تبقى ساعة واحدة على مغادرة رحلتك {route}. يرجى التواجد في {meeting} وإبراز التذكرة.",
  },
  {
    key: "tpl_time_changed",
    type: "time_changed",
    title: "تم تغيير وقت الرحلة",
    def: "تم تغيير موعد رحلتك {route}. الموعد الجديد: {date} الساعة {time}.",
  },
  {
    key: "tpl_seat_changed",
    type: "seat_changed",
    title: "تم تغيير المقعد",
    def: "تم تغيير مقعدك في الحجز {booking} إلى المقعد رقم {seat}.",
  },
  {
    key: "tpl_trip_cancelled",
    type: "trip_cancelled",
    title: "تم إلغاء الرحلة",
    def: "نأسف، تم إلغاء رحلة {route} بتاريخ {date}. سيتم التواصل معك بخصوص الاسترجاع.",
  },
  {
    key: "tpl_payment_rejected",
    type: "payment_rejected",
    title: "تم رفض عملية الدفع",
    def: "تم رفض عملية الدفع للحجز {booking}. {note}",
  },
] as const;

export const DEFAULTS: Record<string, string> = {
  app_name: "BUS AWAY",
  app_logo: "/icons/busaway-512.png",
  app_icon: "/icons/busaway-512.png",
  primary_color: "#0f5c3a",
  contact_phone: "+249 900 000 000",
  contact_email: "support@rihlati.sd",
  contact_address: "الخرطوم - السودان",
  currency: "ج.س",
  hold_minutes: "30",
  employee_chat_allowed: "false",
  terms:
    "1) يلتزم الراكب بالحضور قبل موعد المغادرة بساعة على الأقل.\n2) التذكرة شخصية ولا يجوز التنازل عنها.\n3) تعتبر بيانات التحويل صحيحة بعد مراجعة الشركة وقبولها.\n4) تحتفظ الشركة بحق تغيير موعد الرحلة مع إشعار الراكب.",
  cancellation_policy:
    "يمكن إلغاء الحجز قبل تأكيد الدفع مجاناً. بعد التأكيد يتم الإلغاء عبر الشركة، ويُسترد المبلغ وفق سياسة كل شركة (يخصم 10% كرسوم إدارية إذا كان الإلغاء قبل أقل من 24 ساعة).",
  ...Object.fromEntries(TEMPLATE_META.map((t) => [t.key, t.def])),
};

export type Settings = Record<string, string>;

export const getSettings = cache(async (): Promise<Settings> => {
  try {
    await ensureSeed();
    const rows = await db.select().from(settings);
    const m: Settings = { ...DEFAULTS };
    for (const r of rows) if (r.value !== "") m[r.key] = r.value;
    return m;
  } catch {
    return { ...DEFAULTS };
  }
});

export function renderTpl(tpl: string, vars: Record<string, string | number>): string {
  return tpl.replace(/\{(\w+)\}/g, (_, k) => String(vars[k] ?? ""));
}
