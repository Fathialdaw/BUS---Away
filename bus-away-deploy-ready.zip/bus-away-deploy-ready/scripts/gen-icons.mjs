import fs from "node:fs";
import zlib from "node:zlib";

const crcT = new Int32Array(256).map((_, n) => {
  let c = n;
  for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
  return c;
});
const crc = (buf) => {
  let c = -1;
  for (const b of buf) c = crcT[(c ^ b) & 255] ^ (c >>> 8);
  return (c ^ -1) >>> 0;
};
const chunk = (type, data) => {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length);
  const td = Buffer.concat([Buffer.from(type), data]);
  const c = Buffer.alloc(4);
  c.writeUInt32BE(crc(td));
  return Buffer.concat([len, td, c]);
};
const png = (w, h, px) => {
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(w, 0);
  ihdr.writeUInt32BE(h, 4);
  ihdr[8] = 8;
  ihdr[9] = 6;
  const raw = Buffer.alloc((w * 4 + 1) * h);
  for (let y = 0; y < h; y++) {
    raw[y * (w * 4 + 1)] = 0;
    px.copy(raw, y * (w * 4 + 1) + 1, y * w * 4, (y + 1) * w * 4);
  }
  return Buffer.concat([
    Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]),
    chunk("IHDR", ihdr),
    chunk("IDAT", zlib.deflateSync(raw)),
    chunk("IEND", Buffer.alloc(0)),
  ]);
};
const hex = (h) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16));
const sdRect = (x, y, cx, cy, hw, hh, r) => {
  const dx = Math.abs(x - cx) - hw + r;
  const dy = Math.abs(y - cy) - hh + r;
  return Math.hypot(Math.max(dx, 0), Math.max(dy, 0)) + Math.min(Math.max(dx, dy), 0) - r;
};

function draw(size, color, badge) {
  const px = Buffer.alloc(size * size * 4);
  const bg = hex(color);
  const white = [255, 255, 255];
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const u = (x + 0.5) / size;
      const v = (y + 0.5) / size;
      let col = bg.slice();
      const mix = (c, d) => {
        const a = Math.min(1, Math.max(0, 0.5 - d * size));
        col = col.map((p, i) => p * (1 - a) + c[i] * a);
      };
      mix(white, sdRect(u, v, 0.5, 0.47, 0.27, 0.2, 0.06));
      for (const xs of [0.36, 0.5, 0.64]) mix(bg, sdRect(u, v, xs, 0.42, 0.055, 0.06, 0.015));
      mix(bg, sdRect(u, v, 0.5, 0.56, 0.27, 0.012, 0));
      for (const wx of [0.37, 0.63]) {
        mix(white, Math.hypot(u - wx, v - 0.7) - 0.06);
        mix(bg, Math.hypot(u - wx, v - 0.7) - 0.028);
      }
      if (badge) {
        mix(white, Math.hypot(u - 0.74, v - 0.3) - 0.1);
        mix(bg, Math.hypot(u - 0.74, v - 0.3) - 0.065);
        mix(white, Math.hypot(u - 0.74, v - 0.3) - 0.03);
      }
      const o = (y * size + x) * 4;
      px[o] = col[0];
      px[o + 1] = col[1];
      px[o + 2] = col[2];
      px[o + 3] = 255;
    }
  }
  return png(size, size, px);
}

fs.mkdirSync("public/icons", { recursive: true });
const apps = { passenger: ["#1d4ed8", false], company: ["#0f766e", true], admin: ["#6d28d9", true] };
for (const [name, [color, badge]] of Object.entries(apps)) {
  for (const s of [192, 512]) fs.writeFileSync(`public/icons/${name}-${s}.png`, draw(s, color, badge));
}
console.log("icons done");
