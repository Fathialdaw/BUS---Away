# نشر باص اوي

## الخيار أ: Render (الأسهل - قاعدة وخادم معاً)
1. ارفع المشروع إلى GitHub.
2. في Render: New ← Blueprint ← اختر المستودع (يقرأ `render.yaml` وينشئ القاعدة والخدمة).
3. أدخل كلمات مرور `SEED_*_PASSWORD` عند الطلب.
4. بعد البناء يُنشئ `npm run start:prod` الجداول تلقائياً، ثم تُزرع البيانات الأولية عند أول زيارة.
5. افتح الرابط: `/passenger` و `/company` و `/admin`.

## الخيار ب: Vercel + Neon
1. أنشئ قاعدة على neon.tech وانسخ `DATABASE_URL`.
2. من جهازك: `DATABASE_URL=... npm run db:push`
3. في Vercel: Import المستودع، وأضف المتغيرات من `.env.example` (`DATABASE_URL`, `SESSION_SECRET`, `SEED_*`).

## الخيار ج: Docker / VPS
`SESSION_SECRET=$(openssl rand -base64 32) docker compose up -d --build`
ثم أنشئ الجداول مرة واحدة: `DATABASE_URL=postgresql://postgres:postgres@localhost:5432/app_db npm run db:push` (بعد فتح منفذ القاعدة أو من داخل الشبكة).

## بعد النشر
- غيّر كلمات مرور الحسابات التجريبية من لوحة المدير، واحذف بيانات العرض (إعدادات ← تهيئة/حذف الرحلات والحجوزات).
- PWA يتطلب HTTPS (توفره المنصات تلقائياً).
- فصل التطبيقات بنطاقات فرعية: وجّه `passenger.` و`company.` و`admin.` لنفس الخدمة، فيعمل `middleware.ts` تلقائياً.
- الصور تُحفظ داخل قاعدة البيانات (حد 4MB للملف)، فلا تحتاج تخزيناً خارجياً.
- راقب الصحة عبر `/api/health`.
