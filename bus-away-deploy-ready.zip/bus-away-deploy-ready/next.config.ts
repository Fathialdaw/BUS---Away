import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  poweredByHeader: false,
  // للنشر عبر Docker فقط (BUILD_STANDALONE=1)؛ Vercel لا يحتاجه
  ...(process.env.BUILD_STANDALONE === "1" ? { output: "standalone" as const } : {}),
};

export default nextConfig;
